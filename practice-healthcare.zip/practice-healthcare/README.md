# The Spine Physio — Clinic Website

Website for **The Spine Physio**, the physiotherapy clinic of **Dr. C.P. Sharma (PT)**
(BPT, MPT (Neuro), CDNT, COMT) in Patrakar Colony, Mansarovar, Jaipur.

> **Status:** Level 1 is complete and ready to deploy. Fill in the [pre-launch checklist](#-pre-launch-checklist) first.

---

## Contents
1. [What the website does today](#-what-the-website-does-today)
2. [Tech stack](#-tech-stack)
3. [Quick start](#-quick-start)
4. [Project structure](#-project-structure)
5. [How to edit things](#-how-to-edit-things)
6. [Quality standards (and how they were tested)](#-quality-standards)
7. [Deploying (free)](#-deploying-free)
8. [Pre-launch checklist](#-pre-launch-checklist)
9. [After launch](#-after-launch)
10. [Roadmap: Level 2 → Level 4](#-roadmap)

---

## ✅ What the website does today

| Area | Details |
|---|---|
| **Pages** | Home, About, Services overview, **12 condition & treatment pages**, Contact, Privacy Policy, Terms, Medical Disclaimer, 404 |
| **Booking** | WhatsApp booking form (validates name, Indian mobile number, concern, date, time) that opens WhatsApp with a neat pre-filled message; click-to-call; floating WhatsApp button; sticky **Call / WhatsApp** bar on phones |
| **Photos** | 7 real clinic photos, edited for the site: un-mirrored, cropped, busy backgrounds softly blurred, consistent clinical colour grade |
| **Themes** | Light and dark mode, following the device setting; the ☀/☾ button remembers the visitor's choice |
| **SEO** | Pre-rendered HTML for every page, unique titles/descriptions, canonical URLs, sitemap.xml, robots.txt, Open Graph (nice previews on WhatsApp/Facebook), JSON-LD schema (clinic, doctor, medical pages, FAQs, breadcrumbs) |
| **AEO** (answer engines) | Question-style headings, 40–60 word "Quick answer" boxes, FAQs on every service page |
| **GEO** (AI search) | `llms.txt`, AI crawlers allowed, clear facts, "Reviewed by" + "Last updated" on medical pages |
| **Accessibility** | WCAG 2.2 AA: skip link, landmarks, keyboard menu, visible focus, labelled form with announced errors, AA contrast in both themes, large touch targets, respects "reduce motion" |
| **Speed** | AVIF/WebP images, preloaded hero image and font, zero layout shift, map loads only on click |
| **Security** | Strict Content-Security-Policy, HSTS and other headers via `public/_headers` |
| **Icons** | `favicon.ico` (16/32/48), SVG favicon, Apple touch icon, Android/PWA icons including maskable |

---

## 🧰 Tech stack

| Layer | Choice | Why |
|---|---|---|
| UI | **React 19** + **TypeScript** | Component-based, type-safe |
| Routing | **React Router** | Simple page routing |
| Build | **Vite** | Very fast dev server and builds |
| Styling | **Tailwind CSS 4** with OKLCH colour tokens | Consistent design system, easy light/dark themes |
| SEO rendering | Custom pre-render script (`renderToString`) | Real HTML for Google & AI tools, no server needed |
| Images | **sharp** (`scripts/build-images.mjs`) | Reproducible photo editing and optimisation |
| Hosting | Static files (Cloudflare Pages / Netlify) | Free, fast global CDN |
| Backend | **None yet**; it arrives in Level 2 | Level 1 needs no server |

---

## 🚀 Quick start

Requires **Node.js 20+**.

```bash
npm install          # first time only
npm run dev          # edit with live reload → http://localhost:5173
npm run build        # type-check + build + pre-render → dist/
npm run preview      # serve dist/ like real hosting → http://localhost:4173
npm run images       # re-edit photos & regenerate icons/share image
```

---

## 🗂 Project structure

```
assets-src/                 Original photos (NOT published; edited copies go to public/images)
public/
  images/                   Edited photos (AVIF + WebP) and og-image.jpg  ← generated
  favicon.svg / .ico, icons  App & browser icons                           ← generated from favicon.svg
  _headers                  Security + caching headers for the host
  site.webmanifest          PWA manifest
scripts/
  build-images.mjs          Photo editing pipeline + icons + share image
  prerender.mjs             Renders every page to HTML, writes sitemap/robots/llms.txt, CSP hash
  serve.mjs                 Local production server (used by `npm run preview`)
src/
  lib/
    site.ts                 ★ Clinic details (name, phones, address, hours, doctor…)
    services.ts             ★ All condition/treatment content + FAQs
    photos.ts               ★ Which photo is used where (+ alt text, focal point)
    seo.ts                  Titles, descriptions, schema, sitemap, robots, llms.txt
    ui.ts                   Shared button/layout styles
  components/               Header, Footer, BookingForm, ThemeToggle, MapEmbed, Logo, …
  pages/                    Home, About, Services, ServiceDetail, Contact, Legal, NotFound
  index.css                 ★ Colour system (light + dark), fonts, animations
  App.tsx                   Routes
  main.tsx                  Browser entry (hydration)
  entry-server.tsx          Build-time entry (pre-rendering)
index.html                  HTML template (+ tiny no-flash theme script)
```

---

## ✏️ How to edit things

### Clinic details → `src/lib/site.ts`
Name, phone numbers, WhatsApp number, address, timings, Instagram, domain, doctor qualifications.
Change it once and every page, the schema, sitemap and `llms.txt` update automatically.

### Conditions, treatments and FAQs → `src/lib/services.ts`
Each service has its card text, page heading, SEO title/description, "quick answer", signs, treatment steps and FAQs.
**To add a new service page**, copy one object and edit it. The page, cards, footer link, sitemap entry, schema and booking-form option are created automatically.

### Photos → `assets-src/` + `scripts/build-images.mjs` + `src/lib/photos.ts`
The pipeline edits each original:
1. **Un-mirrors** it (phone selfies flip text, such as the name on the scrubs)
2. **Crops** it to the doctor
3. **Portrait mode:** keeps the doctor sharp and softly blurs busy backgrounds (old signage etc.)
4. Applies one **clinical colour grade** so all photos match the theme
5. Exports **AVIF + WebP** at 400/640/720 px

To add or replace a photo: put the original in `assets-src/`, add a recipe in `build-images.mjs` (crop box and optional sharp/blur areas), register it in `src/lib/photos.ts` with alt text and a focal point, then run `npm run images`.

| Photo | Used on |
|---|---|
| `doctor-hero` (white coat) | Home hero, social share image |
| `doctor-spine` (scrubs + spine model) | Home "Meet your physiotherapist", spine-related service pages |
| `doctor-knee-coat` (white coat + knee model) | About profile, knee & post-surgery pages |
| `doctor-consult` (white coat, writing) | Other service pages, About gallery |
| `doctor-knee-scrubs`, `doctor-desk-writing` | About gallery, sports injury page |
| `doctor-desk` (smiling at desk) | Contact page, About gallery |

### Colours, light & dark mode → `src/index.css`
Colours are **semantic tokens in OKLCH** (a perceptually even colour space). Components use roles such as
`bg-page`, `bg-surface`, `text-heading`, `text-fg-muted`, `text-link`, `bg-primary` and `bg-inverse`, never raw hex codes.
Each role has a light value (`:root`) and a dark value (`[data-theme="dark"]`). Keep text/background pairs at **4.5:1 contrast or more**.

### Favicon & app icons → `public/favicon.svg`
Edit the SVG, then run `npm run images` to regenerate `favicon.ico`, PNG and Apple/Android icons.

### SEO text → `src/lib/seo.ts`
Page titles and descriptions for the static pages; service pages take theirs from `services.ts`.

---

## 🧪 Quality standards

These were verified with automated browser tests (Puppeteer + axe-core) on the production build:

| Check | Result |
|---|---|
| Accessibility (axe, WCAG 2.2 AA + best practices) | **0 violations** on every page, light & dark, mobile & desktop |
| Console / React hydration errors | **0** |
| Horizontal scrolling on phones | **None** on all 20 pages at 320, 360, 375, 390, 393, 412, 414, 430 px, both themes, including the open menu and form errors |
| Core Web Vitals (mobile, Slow 4G + 4× CPU) | LCP ≈ 2.0 s · TBT ≈ 0–100 ms · CLS 0 |
| Lighthouse | Accessibility, Best Practices, SEO: **100** |
| Booking flow | Validation, error focus, phone normalisation and WhatsApp message all verified |

When you change something, re-check at least: `npm run build` passes, the page works at 320 px wide, and both themes are readable.

---

## 🌐 Deploying (free)

**Cloudflare Pages** (recommended: free and allows commercial sites):
1. Push this folder to a GitHub repository.
2. Cloudflare dashboard → **Workers & Pages → Create → Pages → Connect to Git**.
3. Build command: `npm run build` · Output directory: `dist` · Environment variable: `NODE_VERSION = 20`.
4. Add your custom domain under **Custom domains**.

Netlify works the same way (same build command and folder). Both read `public/_headers`.

---

## 📝 Pre-launch checklist

In `src/lib/site.ts`:
- [ ] `url`: the real domain
- [ ] `hours`: clinic timings (until then the site says "call or WhatsApp to confirm timings")
- [ ] `whatsapp`: confirm which number has WhatsApp (currently 96808 37883)
- [ ] `postalCode`: confirm 302020
- [ ] `geo`: exact map coordinates (Google Maps → right-click the clinic → copy coordinates)
- [ ] Confirm qualifications: BPT, MPT (Neuro), CDNT = Certified Dry Needling Therapist, COMT = Certified Orthopaedic Manual Therapist

Also:
- [ ] Have the Privacy Policy / Terms reviewed (they are sensible templates, not legal advice)
- [ ] Make the **Google Business Profile** name match exactly. The site uses "The Spine Physio", but the clinic banner says "Chandra Physiotherapy"; pick one name everywhere.
- [ ] `npm run build` and deploy

---

## 📈 After launch

1. **Google Search Console:** add the site and submit `https://YOUR-DOMAIN/sitemap.xml`.
2. **Google Business Profile:** same name, address and phone as the website; add the clinic photos; choose "Physiotherapist" as the category.
3. **Rich results test:** https://search.google.com/test/rich-results.
4. **Reviews:** ask happy patients for Google reviews. This is the strongest local-SEO signal. Never add made-up testimonials.
5. **Analytics (optional):** Cloudflare Web Analytics is free and cookie-less. Add its domains to the CSP in `public/_headers` (see the comment there).

---

## 🗺 Roadmap

### Level 1: Website ✅ *(done)*
Everything in [What the website does today](#-what-the-website-does-today).

### Level 2: Real booking system *(next)*
| Feature | Notes |
|---|---|
| Online slot booking | Choose service → see free slots → confirm (no double booking) |
| Doctor availability manager | Working days, hours, slot length, breaks, leave |
| Appointment statuses | Pending · Confirmed · Completed · Cancelled · No-show |
| Confirmations | Email and/or WhatsApp to patient and doctor; reschedule/cancel link |
| Admin dashboard | Today's list, calendar view, patient list, enquiry inbox |
| Enquiries saved | Booking-form requests stored in the database (as well as WhatsApp) |
| Testimonials manager | Doctor approves real reviews before they show |
| Blog / articles | Doctor writes posts with SEO fields (strong for ranking) |

**Suggested architecture:** keep this React frontend, and add an API:
- Node.js (Express/Fastify or Hono) + **PostgreSQL** (Neon, free tier) + Prisma ORM
- Auth for the admin (secure, http-only cookies)
- Host the API on Cloudflare Workers / Render / Railway
- Pages that need live data (booking, admin) fetch from the API; marketing pages stay pre-rendered

### Level 3: Clinic management
- Patient portal (login by phone OTP): appointments, reports upload (MRI/X-ray), prescriptions
- Home-exercise programmes with videos/GIFs and daily tick-off
- Clinical notes: assessment, pain scale, diagnosis, progress charts
- Session packages (e.g. 10 sessions) with remaining-session tracking
- Online payments (Razorpay), invoices/receipts (PDF), revenue reports
- Automated reminders (24 h / 1 h) and follow-ups via the WhatsApp Business API; Google-review requests

### Level 4: Advanced / SaaS
- Online video consultations (tele-physio)
- Multiple therapists and branches, with role-based access (admin, therapist, receptionist)
- Multi-tenant SaaS: other physiotherapists sign up and get their own site
- AI assistant: website FAQ chatbot, symptom pre-screening, help drafting articles
- Analytics: booking sources, conversion, retention
- Hindi / regional language versions, installable app (PWA)
- Health-data compliance: consent records, encryption, audit logs

---

## ⚠️ Known limitations (Level 1)
- Bookings are **requests** sent through WhatsApp; nothing is stored, and the clinic confirms manually.
- Some photos come from phone cameras; a professional photo shoot would make them sharper.
- Clinic timings are not yet published (see the checklist).
