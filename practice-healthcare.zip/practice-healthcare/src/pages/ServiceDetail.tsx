import { Link, useParams } from "react-router";
import { Icon } from "@/components/Icon";
import { PageHeader } from "@/components/PageHeader";
import { Reveal } from "@/components/Reveal";
import { Faq } from "@/components/Faq";
import { ServiceCard } from "@/components/ServiceCard";
import { CtaBand } from "@/components/CtaBand";
import { Picture } from "@/components/Picture";
import { photoForService } from "@/lib/photos";
import NotFound from "./NotFound";
import { getService } from "@/lib/services";
import { serviceCrumbs } from "@/lib/seo";
import { primaryPhone, site, whatsappLink } from "@/lib/site";
import { btn, container } from "@/lib/ui";

function formatDate(iso: string) {
  return new Date(`${iso}T00:00:00`).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
}

export default function ServiceDetail() {
  const { slug } = useParams();
  const service = getService(slug);
  if (!service) return <NotFound />;

  const related = service.related.map((r) => getService(r)).filter((s) => s !== undefined);
  const waMessage = `Hello ${site.name}, I would like to book an appointment for ${service.name}.`;

  return (
    <>
      <PageHeader
        crumbs={serviceCrumbs(service)}
        title={service.h1}
        lead={
          <span className="flex flex-wrap items-center gap-x-4 gap-y-2 text-base">
            <span className="inline-flex items-center gap-2">
              <Icon name="shield" className="size-5 text-accent" />
              Reviewed by <Link to="/about" className="font-semibold text-link underline underline-offset-2">{site.doctor.displayName}</Link>
            </span>
            <span className="inline-flex items-center gap-2">
              <Icon name="calendar" className="size-5 text-link" />
              Last updated <time dateTime={site.lastUpdated}>{formatDate(site.lastUpdated)}</time>
            </span>
          </span>
        }
      />

      <div className={`${container} grid gap-12 pb-8 pt-4 lg:grid-cols-12`}>
        <article className="min-w-0 lg:col-span-8">
          {/* Quick answer — written for featured snippets, voice search and AI answers */}
          <Reveal>
            <section aria-labelledby="quick-answer" className="relative overflow-hidden rounded-3xl border border-line-strong bg-gradient-to-br from-subtle to-page p-6 shadow-soft sm:p-8">
              <span className="absolute right-5 top-5 inline-flex size-14 items-center justify-center rounded-2xl bg-primary text-white shadow-lift">
                <Icon name={service.icon} className="size-7" />
              </span>
              <p className="text-sm font-bold uppercase tracking-[0.14em] text-link">Quick answer</p>
              <h2 id="quick-answer" className="mt-2 pr-16 text-xl font-bold sm:text-2xl">
                {service.question}
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-fg-soft">{service.answer}</p>
            </section>
          </Reveal>

          <Reveal as="section" className="mt-12" >
            <h2 className="text-h2">{service.pointsTitle}</h2>
            <ul className="mt-6 grid gap-3 sm:grid-cols-2">
              {service.points.map((p) => (
                <li key={p} className="flex items-start gap-3 rounded-2xl border border-line bg-surface p-4">
                  <span className="mt-0.5 inline-flex size-6 shrink-0 items-center justify-center rounded-full bg-accent-soft text-accent">
                    <Icon name="check" className="size-4" />
                  </span>
                  <span className="text-fg-soft">{p}</span>
                </li>
              ))}
            </ul>
          </Reveal>

          <section className="mt-14" aria-labelledby="approach-title">
            <Reveal>
              <h2 id="approach-title" className="text-h2">
                {service.approachTitle}
              </h2>
            </Reveal>
            <ol className="relative mt-8 space-y-6 border-l-2 border-line-strong pl-8">
              {service.approach.map((a, i) => (
                <Reveal as="li" key={a.title} delay={i * 70} className="relative">
                  <span className="absolute -left-[3.05rem] top-0 inline-flex size-9 items-center justify-center rounded-full bg-primary text-sm font-bold text-white ring-4 ring-page">
                    {i + 1}
                  </span>
                  <h3 className="text-lg font-bold">{a.title}</h3>
                  <p className="mt-1 text-fg-soft">{a.text}</p>
                </Reveal>
              ))}
            </ol>
          </section>

          <section className="mt-14" aria-labelledby="faq-title">
            <Reveal>
              <h2 id="faq-title" className="text-h2">
                Frequently asked questions
              </h2>
            </Reveal>
            <Reveal className="mt-6">
              <Faq items={service.faqs} />
            </Reveal>
          </section>

          <p className="mt-10 rounded-2xl bg-subtle p-5 text-sm leading-relaxed text-fg-soft">
            <strong className="text-heading">Please note:</strong> this page is general information, not a diagnosis.
            Every person is different — book an assessment for advice about your condition. Read our{" "}
            <Link to="/medical-disclaimer" className="font-semibold text-link underline underline-offset-2">
              medical disclaimer
            </Link>
            .
          </p>
        </article>

        {/* Sticky booking card */}
        <aside className="lg:col-span-4" aria-label="Book this treatment">
          <div className="space-y-5 lg:sticky lg:top-28">
            <div className="overflow-hidden rounded-3xl border border-line bg-surface shadow-lift">
              <figure className="relative">
                <Picture
                  photo={photoForService(service.slug)}
                  sizes="(min-width: 1024px) 400px, (min-width: 640px) 600px, 100vw"
                  className="aspect-[4/3] h-auto w-full object-cover lg:aspect-[4/5]"
                />
                <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent p-5 pt-12 text-white">
                  <span className="block font-bold">{site.doctor.displayName}</span>
                  <span className="block text-sm text-white/85">
                    {site.doctor.qualifications.map((q) => q.short).join(" · ")}
                  </span>
                </figcaption>
              </figure>
              <div className="space-y-3 p-5">
                <p className="font-semibold text-heading">Need help with {service.name.toLowerCase()}?</p>
                <Link to={`/contact?concern=${service.slug}#book`} className={`${btn.primary} w-full`}>
                  <Icon name="calendar" className="size-5" />
                  Book appointment
                </Link>
                <a
                  href={whatsappLink(waMessage)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`${btn.whatsapp} w-full`}
                >
                  <Icon name="whatsapp" className="size-5" />
                  WhatsApp us<span className="sr-only"> (opens in a new tab)</span>
                </a>
                <a href={`tel:${primaryPhone.tel}`} className={`${btn.outline} w-full`}>
                  <Icon name="phone" className="size-5" />
                  {primaryPhone.display}
                </a>
              </div>
            </div>
          </div>
        </aside>
      </div>

      {related.length > 0 && (
        <section aria-labelledby="related-title" className="bg-subtle py-16">
          <div className={container}>
            <Reveal>
              <h2 id="related-title" className="text-h2">
                Related services
              </h2>
            </Reveal>
            <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((s, i) => (
                <Reveal as="li" key={s.slug} delay={i * 80}>
                  <ServiceCard service={s} />
                </Reveal>
              ))}
            </ul>
          </div>
        </section>
      )}

      <CtaBand concernSlug={service.slug} />
    </>
  );
}
