import { PageHeader } from "@/components/PageHeader";
import { Reveal } from "@/components/Reveal";
import { ServiceCard } from "@/components/ServiceCard";
import { CtaBand } from "@/components/CtaBand";
import { conditions, treatments } from "@/lib/services";
import { site } from "@/lib/site";
import { container, eyebrow, sectionY } from "@/lib/ui";

export default function Services() {
  return (
    <>
      <PageHeader
        crumbs={[
          { name: "Home", path: "/" },
          { name: "Services", path: "/services" },
        ]}
        title="Physiotherapy services in Mansarovar, Jaipur"
        lead={`From back pain and slip disc to sports injuries and stroke rehabilitation — ${site.name} offers spine-focused, ortho and neuro physiotherapy with modern, evidence-based treatments.`}
      />

      <section aria-labelledby="conditions-title" className={sectionY}>
        <div className={container}>
          <Reveal className="max-w-3xl">
            <p className={eyebrow}>Conditions</p>
            <h2 id="conditions-title" className="text-h2 mt-4">
              Conditions we treat
            </h2>
            <p className="text-lead mt-4 text-fg-soft">
              Choose a condition to learn about symptoms, how we treat it and common questions.
            </p>
          </Reveal>
          <ul className="mt-10 grid gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-4">
            {conditions.map((s, i) => (
              <Reveal as="li" key={s.slug} delay={(i % 4) * 80}>
                <ServiceCard service={s} />
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      <section aria-labelledby="treatments-title" className={`bg-subtle ${sectionY}`}>
        <div className={container}>
          <Reveal className="max-w-3xl">
            <p className={eyebrow}>Treatments</p>
            <h2 id="treatments-title" className="text-h2 mt-4">
              Treatment techniques we use
            </h2>
            <p className="text-lead mt-4 text-fg-soft">
              Every treatment is chosen after your assessment and combined with exercise for lasting results.
            </p>
          </Reveal>
          <ul className="mt-10 grid gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-4">
            {treatments.map((s, i) => (
              <Reveal as="li" key={s.slug} delay={i * 80}>
                <ServiceCard service={s} />
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      <CtaBand title="Not sure which treatment you need?" text="That's what the assessment is for. Book a visit and we'll find the cause and the right plan for you." />
    </>
  );
}
