import { Icon, type IconName } from "@/components/Icon";
import { PageHeader } from "@/components/PageHeader";
import { Picture } from "@/components/Picture";
import { Reveal } from "@/components/Reveal";
import { CtaBand } from "@/components/CtaBand";
import { ServiceCard } from "@/components/ServiceCard";
import { conditions } from "@/lib/services";
import { gallery, photos } from "@/lib/photos";
import { site } from "@/lib/site";
import { container, eyebrow, sectionY } from "@/lib/ui";

const principles: { icon: IconName; title: string; text: string }[] = [
  {
    icon: "clipboard",
    title: "Assess before we treat",
    text: "Every plan starts with a thorough assessment of posture, movement, strength and nerves — so treatment targets the real cause.",
  },
  {
    icon: "message",
    title: "Explain in plain words",
    text: "You'll understand what is causing your pain, what we're doing about it and what you can do at home.",
  },
  {
    icon: "hands",
    title: "Hands-on + exercise",
    text: "Manual therapy and dry needling to ease pain quickly, with exercise to build lasting strength.",
  },
  {
    icon: "trending-up",
    title: "Measure progress",
    text: "We track pain, movement and function so you can see your progress at every visit.",
  },
];

const firstVisit = [
  "A conversation about your symptoms, history, work and goals",
  "Physical assessment — posture, movement, strength and nerve tests",
  "Review of any MRI, X-ray or surgical reports you bring",
  "A clear explanation of the problem and an estimated plan",
  "Initial treatment and simple exercises to start at home",
];

export default function About() {
  return (
    <>
      <PageHeader
        crumbs={[
          { name: "Home", path: "/" },
          { name: "About", path: "/about" },
        ]}
        title={`About ${site.doctor.displayName}`}
        lead={`${site.doctor.jobTitle} and certified manual therapist at ${site.name}, ${site.address.locality}, ${site.address.city} — specialising in ${site.tagline.toLowerCase()}.`}
      />

      <section className={`overflow-x-clip ${sectionY}`} aria-labelledby="profile-title">
        <div className={`${container} grid items-start gap-12 lg:grid-cols-12`}>
          <Reveal className="relative mx-auto w-[calc(100%-1.5rem)] max-w-md sm:w-full lg:sticky lg:top-28 lg:col-span-5">
            <div aria-hidden="true" className="absolute -inset-2 rotate-2 rounded-[2.25rem] bg-gradient-to-br from-primary to-strong sm:-inset-3 sm:rotate-3" />
            <div className="relative overflow-hidden rounded-[2rem] border-4 border-surface shadow-lift">
              <Picture
                photo={photos.kneeCoat}
                sizes="(min-width: 1024px) 420px, 90vw"
                className="aspect-[4/5] h-auto w-full object-cover"
              />
            </div>
            <div className="relative -mt-10 mx-6 rounded-2xl border border-line bg-surface p-5 shadow-lift">
              <p className="text-lg font-extrabold text-heading">{site.doctor.displayName}</p>
              <p className="text-fg-muted">{site.doctor.jobTitle}</p>
            </div>
          </Reveal>

          <div className="lg:col-span-7">
            <Reveal>
              <p className={eyebrow}>
                <Icon name="graduation" className="size-4" />
                Qualifications
              </p>
              <h2 id="profile-title" className="text-h2 mt-4">
                Trained in spine, ortho &amp; neuro care
              </h2>
              <p className="text-lead mt-4 text-fg-soft">{site.doctor.shortBio}</p>
            </Reveal>

            <ul className="mt-8 grid gap-4 sm:grid-cols-2">
              {site.doctor.qualifications.map((q, i) => (
                <Reveal as="li" key={q.short} delay={i * 80}>
                  <div className="card-lift flex h-full items-center gap-4 rounded-2xl border border-line bg-surface p-5 shadow-soft">
                    <span className="inline-flex size-14 shrink-0 items-center justify-center rounded-2xl bg-strong text-base font-extrabold text-white">
                      {q.short}
                    </span>
                    <span className="font-semibold text-heading">{q.long}</span>
                  </div>
                </Reveal>
              ))}
            </ul>

            <Reveal className="mt-14">
              <h2 className="text-h2">How we work</h2>
            </Reveal>
            <ul className="mt-6 grid gap-4 sm:grid-cols-2">
              {principles.map((p, i) => (
                <Reveal as="li" key={p.title} delay={i * 80}>
                  <div className="h-full rounded-2xl bg-subtle p-5">
                    <Icon name={p.icon} className="size-7 text-link" />
                    <h3 className="mt-3 text-lg font-bold">{p.title}</h3>
                    <p className="mt-1.5 text-fg-soft">{p.text}</p>
                  </div>
                </Reveal>
              ))}
            </ul>

            <Reveal className="mt-14">
              <h2 className="text-h2">What happens at your first visit?</h2>
              <ol className="mt-6 space-y-3">
                {firstVisit.map((step, i) => (
                  <li key={step} className="flex items-start gap-4">
                    <span className="inline-flex size-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-white">
                      {i + 1}
                    </span>
                    <span className="pt-1 text-fg-soft">{step}</span>
                  </li>
                ))}
              </ol>
              <p className="mt-6 rounded-2xl border border-line bg-surface p-5 text-fg-soft">
                <strong className="text-heading">Tip:</strong> wear loose, comfortable clothing and bring any reports,
                prescriptions or discharge summaries you have.
              </p>
            </Reveal>
          </div>
        </div>
      </section>

      <section aria-labelledby="gallery-title" className={`overflow-x-clip ${sectionY} pt-0 sm:pt-0 lg:pt-0`}>
        <div className={container}>
          <Reveal className="max-w-2xl">
            <p className={eyebrow}>
              <Icon name="user-heart" className="size-4" />
              Inside the clinic
            </p>
            <h2 id="gallery-title" className="text-h2 mt-4">
              Care you can see
            </h2>
            <p className="text-lead mt-4 text-fg-soft">
              Real moments from {site.name} — no stock photos. Every patient is seen personally by {site.doctor.name}.
            </p>
          </Reveal>
          <ul className="mt-10 grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-4">
            {gallery.map((g, i) => (
              <Reveal as="li" key={g.photo.base} delay={i * 90} className="h-full">
                <figure className="group h-full overflow-hidden rounded-2xl border border-line bg-surface shadow-soft">
                  <div className="overflow-hidden">
                    <Picture
                      photo={g.photo}
                      widths={[400, 640]}
                      sizes="(min-width: 1024px) 300px, 50vw"
                      className="aspect-[4/5] h-auto w-full object-cover transition duration-700 ease-out group-hover:scale-105"
                    />
                  </div>
                  <figcaption className="p-3 text-sm font-medium text-fg-soft sm:p-4 sm:text-base">{g.caption}</figcaption>
                </figure>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      <section aria-labelledby="treat-title" className={`bg-subtle ${sectionY}`}>
        <div className={container}>
          <Reveal className="max-w-2xl">
            <h2 id="treat-title" className="text-h2">
              Conditions {site.doctor.name} treats
            </h2>
          </Reveal>
          <ul className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {conditions.map((s, i) => (
              <Reveal as="li" key={s.slug} delay={(i % 4) * 70}>
                <ServiceCard service={s} compact />
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      <CtaBand />
    </>
  );
}
