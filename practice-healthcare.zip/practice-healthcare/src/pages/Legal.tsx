import type { ReactNode } from "react";
import { Link } from "react-router";
import { PageHeader } from "@/components/PageHeader";
import { fullAddress, primaryPhone, site } from "@/lib/site";
import { container } from "@/lib/ui";

function LegalPage({ path, title, children }: { path: string; title: string; children: ReactNode }) {
  const updated = new Date(`${site.lastUpdated}T00:00:00`).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  return (
    <>
      <PageHeader
        crumbs={[
          { name: "Home", path: "/" },
          { name: title, path },
        ]}
        title={title}
        lead={
          <>
            Last updated <time dateTime={site.lastUpdated}>{updated}</time>
          </>
        }
      />
      <div className={`${container} pb-20`}>
        <div className="prose-clinic max-w-3xl">{children}</div>
      </div>
    </>
  );
}

const Contact = () => (
  <p>
    Questions? Contact {site.name}, {fullAddress}, or call <a href={`tel:${primaryPhone.tel}`}>{primaryPhone.display}</a>.
  </p>
);

export function PrivacyPolicy() {
  return (
    <LegalPage path="/privacy-policy" title="Privacy Policy">
      <p>
        {site.name} (&quot;we&quot;, &quot;us&quot;) respects your privacy. This policy explains what happens to the
        information you share when you use this website.
      </p>
      <h2>Information we collect</h2>
      <p>
        This website does <strong>not</strong> store the details you type into the booking form. When you press
        &quot;Send booking request on WhatsApp&quot;, your details are placed into a WhatsApp message on your own device,
        and nothing is sent to us until you choose to send that message.
      </p>
      <p>When you contact us by WhatsApp or phone, we receive the information you choose to share, such as:</p>
      <ul>
        <li>your name and mobile number</li>
        <li>the health concern you need help with and your preferred appointment time</li>
        <li>any other details you include in your message</li>
      </ul>
      <h2>How we use your information</h2>
      <ul>
        <li>to respond to your enquiry and arrange appointments</li>
        <li>to provide physiotherapy care and keep appropriate clinical records</li>
        <li>to send appointment reminders or follow-up messages you would reasonably expect</li>
      </ul>
      <p>We do not sell your personal information or share it for marketing.</p>
      <h2>WhatsApp</h2>
      <p>
        Messages sent through WhatsApp are also subject to WhatsApp&apos;s own privacy policy. Please avoid sharing
        detailed medical records over chat — bring them to your appointment instead.
      </p>
      <h2>Website hosting and analytics</h2>
      <p>
        Our hosting provider may keep standard technical logs (such as IP address and browser type) to keep the site
        secure. We do not use advertising or tracking cookies.
      </p>
      <h2>Your choices</h2>
      <p>
        You can ask us to update or delete the information we hold about you by contacting us, subject to any records
        we are legally required to keep.
      </p>
      <Contact />
    </LegalPage>
  );
}

export function Terms() {
  return (
    <LegalPage path="/terms" title="Terms of Use">
      <p>By using this website you agree to these terms.</p>
      <h2>Use of information</h2>
      <p>
        Content on this website is for general information only and is not medical advice. See our{" "}
        <Link to="/medical-disclaimer">medical disclaimer</Link>.
      </p>
      <h2>Appointments</h2>
      <p>
        A booking request sent through this website or WhatsApp is not a confirmed appointment until we reply to
        confirm the date and time. Please let us know as early as possible if you need to cancel or reschedule.
      </p>
      <h2>Intellectual property</h2>
      <p>
        The text, logo, photographs and design of this website belong to {site.name} and may not be copied without
        permission.
      </p>
      <h2>External links</h2>
      <p>
        This site links to third-party services such as WhatsApp, Google Maps and Instagram. We are not responsible for
        their content or policies.
      </p>
      <h2>Changes</h2>
      <p>We may update these terms from time to time. The date at the top of this page shows the latest version.</p>
      <Contact />
    </LegalPage>
  );
}

export function MedicalDisclaimer() {
  return (
    <LegalPage path="/medical-disclaimer" title="Medical Disclaimer">
      <p>
        The information on this website is provided for general education about physiotherapy and musculoskeletal and
        neurological conditions. It is <strong>not</strong> a substitute for an in-person assessment, diagnosis or
        treatment by a qualified health professional.
      </p>
      <h2>Every person is different</h2>
      <p>
        Recovery times, number of sessions and results vary from person to person. Nothing on this website is a
        guarantee of a particular outcome.
      </p>
      <h2>When to seek urgent medical care</h2>
      <p>Do not wait for a physiotherapy appointment — contact a doctor or emergency services — if you have:</p>
      <ul>
        <li>loss of bladder or bowel control, or numbness around the groin or inner thighs</li>
        <li>sudden or rapidly worsening weakness in the arms or legs</li>
        <li>chest pain, difficulty breathing, or signs of a stroke (face drooping, arm weakness, slurred speech)</li>
        <li>pain after a serious fall or accident, or with fever, or unexplained weight loss</li>
        <li>calf pain, swelling and redness after surgery</li>
      </ul>
      <h2>Exercises</h2>
      <p>
        Only perform exercises that have been prescribed for you after an assessment. Stop and seek advice if an
        exercise causes sharp or increasing pain.
      </p>
      <Contact />
    </LegalPage>
  );
}
