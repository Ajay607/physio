import { Link } from "react-router";
import { Icon } from "@/components/Icon";
import { LogoMark } from "@/components/Logo";
import { btn, container } from "@/lib/ui";

export default function NotFound() {
  return (
    <section className={`${container} flex flex-col items-center py-20 text-center sm:py-28`}>
      <LogoMark animated className="size-24" />
      <p className="mt-6 text-sm font-bold uppercase tracking-[0.2em] text-link">Error 404</p>
      <h1 className="text-display mt-3">This page has slipped out of place</h1>
      <p className="text-lead mt-4 max-w-xl text-fg-soft">
        The page you&apos;re looking for doesn&apos;t exist or has moved. Let&apos;s get you back on track.
      </p>
      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <Link to="/" className={btn.primary}>
          Go to home page
        </Link>
        <Link to="/services" className={btn.outline}>
          View services
          <Icon name="arrow-right" className="size-5" />
        </Link>
      </div>
    </section>
  );
}
