import { Link } from "react-router";
import { Icon, type IconName } from "@/components/Icon";
import { LogoMark } from "@/components/Logo";
import { Picture } from "@/components/Picture";
import { Reveal } from "@/components/Reveal";
import { ServiceCard } from "@/components/ServiceCard";
import { BookingSection } from "@/components/BookingSection";
import { Faq } from "@/components/Faq";
import { ExternalLink } from "@/components/ExternalLink";
import { conditions, homeFaqs, treatments } from "@/lib/services";
import { heroImage } from "@/lib/seo";
import { photos } from "@/lib/photos";
import { fullAddress, mapsUrl, primaryPhone, site, whatsappLink, defaultWhatsAppMessage } from "@/lib/site";
import { btn, container, eyebrow, sectionY } from "@/lib/ui";

const whyUs: { icon: IconName; title: string; text: string }[] = [
  {
    icon: "user-heart",
    title: "Personalised treatment plans",
    text: "No two bodies are the same. Your plan is built around your assessment, your goals and your daily routine.",
  },
  {
    icon: "flask",
    title: "Evidence-based care",
    text: "Treatments backed by current research — manual therapy, dry needling and exercise, not guesswork.",
  },
  {
    icon: "run",
    title: "Sports rehabilitation",
    text: "From weekend players to athletes — structured rehab to get you back to sport stronger and safer.",
  },
  {
    icon: "shield",
    title: "Safe, progressive recovery",
    text: "Step-by-step progress you can see, with clear home exercises between sessions.",
  },
];

const steps: { icon: IconName; title: string; text: string }[] = [
  {
    icon: "message",
    title: "Book in a minute",
    text: "Send the form, WhatsApp us or call. We'll confirm a time that suits you.",
  },
  {
    icon: "clipboard",
    title: "Detailed assessment",
    text: "We find the real cause of your pain and explain it in simple words.",
  },
  {
    icon: "trending-up",
    title: "Treat & recover",
    text: "Hands-on treatment plus a personalised exercise plan to keep you improving.",
  },
];

function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-subtle via-page to-page">
      {/* Decorative background */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="absolute -right-40 -top-40 size-[34rem] rounded-full bg-soft/70 blur-3xl motion-safe:animate-float" />
        <div className="absolute -left-24 bottom-0 size-80 rounded-full bg-accent-soft/60 blur-3xl motion-safe:animate-float motion-safe:[animation-delay:-3s]" />
        <div className="absolute inset-0 bg-[radial-gradient(var(--color-line-strong)_1px,transparent_1px)] [background-size:28px_28px] opacity-40 [mask-image:linear-gradient(to_bottom,black,transparent_75%)]" />
      </div>

      <div className={`${container} relative grid items-center gap-12 pb-16 pt-10 sm:pt-14 lg:grid-cols-12 lg:gap-8 lg:pb-24 lg:pt-16`}>
        <div className="lg:col-span-7">
          <p className={`${eyebrow} motion-safe:animate-fade-up`}>
            <span className="relative flex size-2.5" aria-hidden="true">
              <span className="absolute inline-flex size-full rounded-full bg-accent opacity-60 motion-safe:animate-ping" />
              <span className="relative inline-flex size-2.5 rounded-full bg-accent" />
            </span>
            {site.slogan}
          </p>

          <h1 className="text-display mt-5 motion-safe:animate-fade-up motion-safe:[animation-delay:80ms]">
            Expert spine &amp; joint physiotherapy in{" "}
            <span className="bg-gradient-to-r from-grad-a to-grad-b bg-clip-text text-transparent">
              Mansarovar, Jaipur
            </span>
          </h1>

          <p className="text-lead mt-5 max-w-2xl text-fg-soft motion-safe:animate-fade-up motion-safe:[animation-delay:160ms]">
            Personalised, evidence-based treatment for back pain, slip disc, sports injuries, joint pain and neuro
            rehabilitation — by <strong className="text-heading">{site.doctor.displayName}</strong>, consultant
            physiotherapist &amp; manual therapist.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row motion-safe:animate-fade-up motion-safe:[animation-delay:240ms]">
            <Link to="/contact#book" className={btn.primary}>
              <Icon name="calendar" className="size-5" />
              Book appointment
            </Link>
            <a href={whatsappLink(defaultWhatsAppMessage)} target="_blank" rel="noopener noreferrer" className={btn.whatsapp}>
              <Icon name="whatsapp" className="size-5" />
              Chat on WhatsApp<span className="sr-only"> (opens in a new tab)</span>
            </a>
          </div>

          <ul className="mt-8 grid gap-3 text-fg-soft sm:grid-cols-2 motion-safe:animate-fade-up motion-safe:[animation-delay:320ms]">
            {[
              "BPT, MPT (Neuro) physiotherapist",
              "Certified dry needling therapist",
              "Certified orthopaedic manual therapist",
              "Ortho & neuro rehabilitation",
            ].map((t) => (
              <li key={t} className="flex items-center gap-2.5">
                <span className="inline-flex size-6 shrink-0 items-center justify-center rounded-full bg-accent-soft text-accent">
                  <Icon name="check" className="size-4" />
                </span>
                {t}
              </li>
            ))}
          </ul>
        </div>

        {/* Doctor photo with floating cards */}
        <div className="relative mx-auto w-full max-w-sm sm:max-w-md lg:col-span-5 lg:max-w-none">
          <div className="relative mx-auto w-[80%] max-w-[440px] motion-safe:animate-fade-in">
            <div
              aria-hidden="true"
              className="absolute -inset-4 rotate-6 rounded-[2.5rem] bg-gradient-to-br from-primary to-strong opacity-90"
            />
            <div className="relative overflow-hidden rounded-[2rem] border-4 border-surface bg-soft shadow-lift">
              <Picture
                photo={photos.hero}
                widths={heroImage.widths}
                sizes={heroImage.sizes}
                priority
                className="aspect-[4/5] h-auto w-full object-cover"
              />
            </div>

            {/* Animated logo badge */}
            <div className="absolute -left-6 top-6 rounded-2xl bg-surface p-2.5 shadow-lift motion-safe:animate-float sm:-left-10">
              <LogoMark animated className="size-14 sm:size-16" />
            </div>

            <div className="absolute -bottom-6 -left-4 right-6 rounded-2xl border border-line bg-page/95 p-4 shadow-lift backdrop-blur sm:-left-10 motion-safe:animate-fade-up motion-safe:[animation-delay:500ms]">
              <p className="text-lg font-extrabold text-heading">{site.doctor.displayName}</p>
              <p className="text-sm text-fg-muted">{site.doctor.jobTitle}</p>
              <p className="mt-1.5 text-sm font-semibold text-link">
                {site.doctor.qualifications.map((q) => q.short).join(" · ")}
              </p>
            </div>

            <div className="absolute -right-3 top-[58%] hidden items-center gap-2 rounded-full bg-surface px-4 py-2.5 text-sm font-semibold text-heading shadow-lift sm:flex motion-safe:animate-float motion-safe:[animation-delay:-2s]">
              <span className="inline-flex size-7 items-center justify-center rounded-full bg-soft text-link">
                <Icon name="brain" className="size-4" />
              </span>
              Ortho &amp; Neuro Rehab
            </div>
          </div>
        </div>
      </div>

      {/* Wave divider */}
      <svg aria-hidden="true" className="block h-8 w-full text-page sm:h-12" viewBox="0 0 1440 48" preserveAspectRatio="none">
        <path fill="currentColor" d="M0 48h1440V20c-200 22-420 30-720 8S180 0 0 22z" />
      </svg>
    </section>
  );
}

function SectionHeading({ kicker, title, text, id }: { kicker: string; title: string; text?: string; id: string }) {
  return (
    <Reveal className="mx-auto max-w-3xl text-center">
      <p className={eyebrow}>{kicker}</p>
      <h2 id={id} className="text-h2 mt-4">
        {title}
      </h2>
      {text && <p className="text-lead mt-4 text-fg-soft">{text}</p>}
    </Reveal>
  );
}

export default function Home() {
  return (
    <>
      <Hero />

      {/* Conditions */}
      <section aria-labelledby="conditions-title" className={sectionY}>
        <div className={container}>
          <SectionHeading
            id="conditions-title"
            kicker="Conditions we treat"
            title="Relief for spine, joint, sports & nerve problems"
            text="Whether it's a stiff neck from desk work or recovery after a stroke, we treat the cause — not just the pain."
          />
          <ul className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-4">
            {conditions.map((s, i) => (
              <Reveal as="li" key={s.slug} delay={(i % 4) * 80}>
                <ServiceCard service={s} />
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* Treatments */}
      <section aria-labelledby="treatments-title" className={`relative overflow-hidden bg-inverse text-white ${sectionY}`}>
        <div aria-hidden="true" className="pointer-events-none absolute -right-40 top-0 size-[30rem] rounded-full bg-primary/30 blur-3xl" />
        <div className={`${container} relative`}>
          <Reveal className="mx-auto max-w-3xl text-center">
            <p className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3.5 py-1.5 text-sm font-semibold text-on-inverse-accent">
              Our treatment services
            </p>
            <h2 id="treatments-title" className="text-h2 mt-4 text-white">
              Hands-on care, modern techniques
            </h2>
            <p className="text-lead mt-4 text-white/80">
              Every treatment is chosen after a proper assessment and combined with exercise for lasting results.
            </p>
          </Reveal>
          <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {treatments.map((s, i) => (
              <Reveal as="li" key={s.slug} delay={i * 90}>
                <Link
                  to={`/services/${s.slug}`}
                  className="group flex h-full flex-col rounded-2xl border border-white/10 bg-white/5 p-6 transition duration-300 hover:-translate-y-1 hover:border-on-inverse-accent/50 hover:bg-white/10"
                >
                  <span className="inline-flex size-14 items-center justify-center rounded-2xl bg-primary text-white shadow-lift transition duration-300 group-hover:rotate-6 group-hover:scale-110">
                    <Icon name={s.icon} className="size-7" />
                  </span>
                  <h3 className="mt-5 text-xl font-bold text-white">{s.name}</h3>
                  <p className="mt-2 text-white/80">{s.summary}</p>
                  <span className="mt-auto inline-flex items-center gap-1.5 pt-5 text-sm font-semibold text-on-inverse-accent">
                    Learn more<span className="sr-only"> about {s.name}</span>
                    <Icon name="arrow-right" className="size-4 transition-transform group-hover:translate-x-1" />
                  </span>
                </Link>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* Why choose us */}
      <section aria-labelledby="why-title" className={sectionY}>
        <div className={container}>
          <SectionHeading
            id="why-title"
            kicker="Why The Spine Physio"
            title="Care that's clear, personal and proven"
          />
          <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {whyUs.map((w, i) => (
              <Reveal as="li" key={w.title} delay={i * 80} className="h-full">
                <div className="card-lift h-full rounded-2xl border border-line bg-gradient-to-b from-surface to-subtle p-6 shadow-soft">
                  <span className="inline-flex size-12 items-center justify-center rounded-xl bg-strong text-white">
                    <Icon name={w.icon} className="size-6" />
                  </span>
                  <h3 className="mt-4 text-lg font-bold">{w.title}</h3>
                  <p className="mt-2 text-fg-muted">{w.text}</p>
                </div>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* Meet the doctor */}
      <section aria-labelledby="doctor-title" className={`overflow-x-clip bg-gradient-to-b from-page to-subtle ${sectionY}`}>
        <div className={`${container} grid items-center gap-12 lg:grid-cols-2`}>
          <Reveal className="relative mx-auto w-[calc(100%-1.5rem)] max-w-md sm:w-full">
            <div aria-hidden="true" className="absolute -inset-2 -rotate-2 rounded-[2.25rem] bg-soft-strong sm:-inset-3 sm:-rotate-3" />
            <div className="relative overflow-hidden rounded-[2rem] border-4 border-surface shadow-lift">
              <Picture
                photo={photos.spine}
                sizes="(min-width: 1024px) 448px, 90vw"
                className="aspect-[5/8] h-auto max-h-[38rem] w-full object-cover object-top"
              />
            </div>
          </Reveal>
          <Reveal delay={100}>
            <p className={eyebrow}>
              <Icon name="graduation" className="size-4" />
              Meet your physiotherapist
            </p>
            <h2 id="doctor-title" className="text-h2 mt-4">
              {site.doctor.displayName}
            </h2>
            <p className="mt-1 text-lg font-semibold text-link">
              {site.doctor.jobTitle} &amp; Manual Therapist
            </p>
            <p className="text-lead mt-5 text-fg-soft">
              {site.doctor.displayName} specialises in spine, orthopaedic and neurological rehabilitation — combining
              certified manual therapy and dry needling with targeted exercise to treat the cause of pain, and teaching
              you how to keep it from coming back.
            </p>
            <ul className="mt-6 flex flex-wrap gap-2.5">
              {site.doctor.qualifications.map((q) => (
                <li
                  key={q.short}
                  className="rounded-full border border-line-strong bg-surface px-4 py-2 text-sm font-semibold text-heading shadow-soft"
                >
                  <abbr title={q.long} className="no-underline">
                    {q.short}
                  </abbr>
                  <span className="sr-only"> — {q.long}</span>
                </li>
              ))}
            </ul>
            <Link to="/about" className={`${btn.outline} mt-8`}>
              About {site.doctor.name}
              <Icon name="arrow-right" className="size-5" />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* How it works */}
      <section aria-labelledby="steps-title" className={sectionY}>
        <div className={container}>
          <SectionHeading id="steps-title" kicker="How it works" title="Three simple steps to feeling better" />
          <div className="relative mt-14">
          <div
            aria-hidden="true"
            className="absolute left-[16.6%] right-[16.6%] top-8 hidden h-0.5 bg-gradient-to-r from-soft-strong via-primary to-soft-strong md:block"
          />
          <ol className="relative grid gap-10 md:grid-cols-3 md:gap-6">
            {steps.map((s, i) => (
              <Reveal as="li" key={s.title} delay={i * 150} className="relative text-center">
                <span className="relative mx-auto flex size-16 items-center justify-center rounded-full bg-primary text-white shadow-lift ring-8 ring-page">
                  <Icon name={s.icon} className="size-7" />
                  <span className="absolute -right-1 -top-1 flex size-7 items-center justify-center rounded-full bg-inverse text-sm font-bold">
                    {i + 1}
                  </span>
                </span>
                <h3 className="mt-5 text-xl font-bold">{s.title}</h3>
                <p className="mx-auto mt-2 max-w-xs text-fg-muted">{s.text}</p>
              </Reveal>
            ))}
          </ol>
          </div>
        </div>
      </section>

      <BookingSection />

      {/* FAQ */}
      <section aria-labelledby="faq-title" className={sectionY}>
        <div className={`${container} grid gap-10 lg:grid-cols-12`}>
          <Reveal className="lg:col-span-4">
            <p className={eyebrow}>FAQ</p>
            <h2 id="faq-title" className="text-h2 mt-4">
              Questions patients often ask
            </h2>
            <p className="mt-4 text-fg-soft">
              Can&apos;t find your answer?{" "}
              <a href={`tel:${primaryPhone.tel}`} className="font-semibold text-link underline underline-offset-2">
                Call {primaryPhone.display}
              </a>{" "}
              or message us on WhatsApp.
            </p>
          </Reveal>
          <Reveal delay={100} className="lg:col-span-8">
            <Faq items={homeFaqs} />
          </Reveal>
        </div>
      </section>

      {/* Location strip */}
      <section aria-labelledby="visit-title" className="pb-16 sm:pb-20">
        <div className={container}>
          <Reveal>
            <div className="flex flex-col gap-6 rounded-3xl border border-line bg-subtle p-6 sm:p-8 md:flex-row md:items-center md:justify-between">
              <div className="flex items-start gap-4">
                <span className="inline-flex size-14 shrink-0 items-center justify-center rounded-2xl bg-primary text-white">
                  <Icon name="map-pin" className="size-7" />
                </span>
                <div>
                  <h2 id="visit-title" className="text-xl font-bold sm:text-2xl">
                    Visit the clinic
                  </h2>
                  <p className="mt-1 text-fg-soft">{fullAddress}</p>
                  <p className="text-sm text-fg-muted">{site.address.landmark}</p>
                </div>
              </div>
              <ExternalLink href={mapsUrl} className={`${btn.primary} shrink-0`}>
                Get directions
                <Icon name="arrow-right" className="size-5" />
              </ExternalLink>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
