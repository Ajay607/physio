import { Icon, type IconName } from "@/components/Icon";
import { PageHeader } from "@/components/PageHeader";
import { Reveal } from "@/components/Reveal";
import { BookingSection } from "@/components/BookingSection";
import { MapEmbed } from "@/components/MapEmbed";
import { Picture } from "@/components/Picture";
import { photos } from "@/lib/photos";
import { ExternalLink } from "@/components/ExternalLink";
import { fullAddress, mapsUrl, site, whatsappLink, defaultWhatsAppMessage } from "@/lib/site";
import { container, sectionY } from "@/lib/ui";
import type { ReactNode } from "react";

function InfoCard({ icon, title, children, tone = "brand" }: { icon: IconName; title: string; children: ReactNode; tone?: "brand" | "whatsapp" }) {
  return (
    <div className="card-lift flex h-full gap-4 rounded-2xl border border-line bg-surface p-5 shadow-soft">
      <span
        className={`inline-flex size-12 shrink-0 items-center justify-center rounded-xl ${
          tone === "whatsapp" ? "bg-accent-soft text-whatsapp" : "bg-soft text-link"
        }`}
      >
        <Icon name={icon} className="size-6" />
      </span>
      <div className="min-w-0">
        <h2 className="text-lg font-bold">{title}</h2>
        <div className="mt-1 text-fg-soft">{children}</div>
      </div>
    </div>
  );
}

const linkClass = "font-semibold text-link underline-offset-4 hover:underline";

export default function Contact() {
  return (
    <>
      <PageHeader
        crumbs={[
          { name: "Home", path: "/" },
          { name: "Contact", path: "/contact" },
        ]}
        title="Contact & book an appointment"
        lead={`Visit ${site.name} in ${site.address.locality}, ${site.address.city}, call us, or send a booking request on WhatsApp — we'll confirm your time.`}
      />

      <section aria-label="Contact details" className="pb-4">
        <div className={container}>
          <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Reveal as="li">
              <InfoCard icon="map-pin" title="Address">
                <address className="not-italic">
                  {fullAddress}
                  <span className="block text-sm text-fg-muted">{site.address.landmark}</span>
                </address>
                <ExternalLink href={mapsUrl} className={`${linkClass} mt-2 inline-block text-sm`}>
                  Get directions
                </ExternalLink>
              </InfoCard>
            </Reveal>
            <Reveal as="li" delay={80}>
              <InfoCard icon="phone" title="Call us">
                <ul className="space-y-1">
                  {site.phones.map((p) => (
                    <li key={p.tel}>
                      <a href={`tel:${p.tel}`} className={linkClass}>
                        {p.display}
                      </a>
                    </li>
                  ))}
                </ul>
              </InfoCard>
            </Reveal>
            <Reveal as="li" delay={160}>
              <InfoCard icon="whatsapp" title="WhatsApp" tone="whatsapp">
                <p>Quick replies for bookings and questions.</p>
                <ExternalLink href={whatsappLink(defaultWhatsAppMessage)} className={`${linkClass} mt-1 inline-block`}>
                  Start a chat
                </ExternalLink>
              </InfoCard>
            </Reveal>
            <Reveal as="li" delay={240}>
              <InfoCard icon="clock" title="Timings">
                {site.hours.length ? (
                  <ul className="space-y-1">
                    {site.hours.map((h) => (
                      <li key={h.label}>
                        <span className="font-semibold">{h.label}:</span> {h.opens}–{h.closes}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p>Please call or WhatsApp to confirm today&apos;s timings.</p>
                )}
              </InfoCard>
            </Reveal>
          </ul>

          <Reveal className="mt-4">
            <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-line bg-surface p-5">
              <span className="inline-flex items-center gap-2 font-semibold text-heading">
                <Icon name="instagram" className="size-5 text-link" />
                Follow us on Instagram:
              </span>
              {site.social.map((s) => (
                <ExternalLink
                  key={s.handle}
                  href={s.url}
                  className="inline-flex min-h-11 items-center rounded-full bg-subtle px-4 font-semibold text-link transition hover:bg-soft"
                >
                  @{s.handle}
                </ExternalLink>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <BookingSection />

      <section aria-labelledby="map-title" className={sectionY}>
        <div className={container}>
          <Reveal className="mb-8 max-w-2xl">
            <h2 id="map-title" className="text-h2">
              Find the clinic
            </h2>
            <p className="text-lead mt-3 text-fg-soft">
              We&apos;re at {site.address.building}, {site.address.street}, {site.address.locality} (
              {site.address.landmark}).
            </p>
          </Reveal>
          <div className="grid items-start gap-6 lg:grid-cols-5">
            <Reveal className="lg:col-span-2">
              <figure className="overflow-hidden rounded-3xl border border-line bg-surface shadow-soft">
                <Picture
                  photo={photos.desk}
                  sizes="(min-width: 1024px) 460px, 100vw"
                  className="aspect-[4/3] h-auto w-full object-cover"
                />
                <figcaption className="p-5">
                  <span className="block font-bold text-heading">We look forward to meeting you</span>
                  <span className="mt-1 block text-fg-muted">
                    {site.doctor.displayName} sees every patient personally.
                  </span>
                </figcaption>
              </figure>
            </Reveal>
            <Reveal delay={100} className="lg:col-span-3">
              <MapEmbed />
            </Reveal>
          </div>
        </div>
      </section>
    </>
  );
}
