import "@fontsource-variable/plus-jakarta-sans/wght.css";
import "./index.css";
import { StrictMode, startTransition } from "react";
import { createRoot, hydrateRoot } from "react-dom/client";
import { BrowserRouter } from "react-router";
import App from "./App";

const container = document.getElementById("root")!;
const app = (
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>
);

// Production pages are pre-rendered to HTML → hydrate them. In `npm run dev` the root is empty → render.
// Hydrating inside startTransition lets React split the work into small chunks,
// so the page stays responsive on slow phones (lower Total Blocking Time / INP).
if (container.firstElementChild) {
  startTransition(() => {
    hydrateRoot(container, app);
  });
} else {
  createRoot(container).render(app);
}
