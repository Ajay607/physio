import type { IconName } from "@/components/Icon";

export type Faq = { q: string; a: string };

export type Service = {
  slug: string;
  kind: "condition" | "treatment";
  icon: IconName;
  /** Short name used on cards and menus */
  name: string;
  /** One-line card summary */
  summary: string;
  h1: string;
  metaTitle: string;
  metaDescription: string;
  /** "What is it / how does physio help" — a direct 40–60 word answer (AEO / featured snippets) */
  question: string;
  answer: string;
  /** Conditions: common signs. Treatments: what it helps with. */
  pointsTitle: string;
  points: string[];
  approachTitle: string;
  approach: { title: string; text: string }[];
  faqs: Faq[];
  related: string[];
};

export const services: Service[] = [
  /* ───────────────────────── CONDITIONS ───────────────────────── */
  {
    slug: "back-neck-pain-treatment",
    kind: "condition",
    icon: "spine",
    name: "Back & Neck Pain",
    summary: "Disc problems, sciatica, cervical pain",
    h1: "Back & Neck Pain Treatment in Mansarovar, Jaipur",
    metaTitle: "Back & Neck Pain Physiotherapy in Mansarovar, Jaipur",
    metaDescription:
      "Physiotherapy for lower back pain, neck pain and cervical problems in Mansarovar, Jaipur. Manual therapy, dry needling and exercise by Dr. C.P. Sharma (PT).",
    question: "How does physiotherapy treat back and neck pain?",
    answer:
      "Physiotherapy treats back and neck pain by finding the cause — such as a stiff joint, weak core muscles, poor posture or an irritated nerve — and correcting it with hands-on manual therapy, targeted exercise and pain-relief methods. At The Spine Physio, Dr. C.P. Sharma (PT) builds a personalised plan to reduce pain and help stop it coming back.",
    pointsTitle: "Common signs we treat",
    points: [
      "Constant or recurring lower back ache",
      "Neck stiffness from long hours on a desk, laptop or phone",
      "Pain spreading into the shoulder, arm, buttock or leg",
      "Tingling, numbness or weakness in the arms or legs",
      "Pain or stiffness when bending, sitting or standing for long",
    ],
    approachTitle: "How we treat it",
    approach: [
      { title: "Detailed assessment", text: "Posture, movement and nerve tests, plus a review of any MRI or X-ray reports you bring." },
      { title: "Manual therapy", text: "Hands-on joint mobilisation and soft-tissue techniques to ease stiffness and pain." },
      { title: "Dry needling & cupping", text: "Used where suitable to release tight trigger points in the back and neck muscles." },
      { title: "Electrotherapy", text: "IFT or TENS for short-term pain relief, so you can move and exercise comfortably." },
      { title: "Exercise & ergonomics", text: "Core and neck strengthening, posture habits and a simple home programme." },
    ],
    faqs: [
      {
        q: "How many physiotherapy sessions will I need for back pain?",
        a: "It depends on the cause and how long you've had the pain. Many people with recent back or neck pain notice a clear improvement within a few sessions, while long-standing problems usually need a longer plan. You'll get an estimate after your first assessment.",
      },
      {
        q: "Do I need an MRI or X-ray before starting physiotherapy?",
        a: "Not always. Most back and neck pain can be assessed clinically. If you already have reports, bring them along. If any warning signs are found, you'll be advised to see a doctor for further tests.",
      },
      {
        q: "When is back pain an emergency?",
        a: "Seek urgent medical care if back pain comes with loss of bladder or bowel control, numbness around the groin, sudden leg weakness, fever, unexplained weight loss, or follows a major fall or accident.",
      },
    ],
    related: ["slip-disc-sciatica-treatment", "posture-correction", "manual-therapy"],
  },
  {
    slug: "slip-disc-sciatica-treatment",
    kind: "condition",
    icon: "disc",
    name: "Slip Disc & Sciatica",
    summary: "Disc bulge, sciatica, stiffness",
    h1: "Slip Disc & Sciatica Treatment in Jaipur",
    metaTitle: "Slip Disc & Sciatica Treatment Without Surgery | Jaipur",
    metaDescription:
      "Non-surgical physiotherapy for slip disc, disc bulge and sciatica pain in Mansarovar, Jaipur. Spine-focused care by Dr. C.P. Sharma (PT), BPT, MPT.",
    question: "What is a slip disc and how does physiotherapy help sciatica?",
    answer:
      "A slip disc (disc bulge or herniation) happens when a spinal disc presses on nearby nerves, often causing sciatica — pain, tingling or numbness that travels from the lower back down the leg. Most cases improve without surgery. Physiotherapy helps by calming the irritated nerve, restoring movement and strengthening the spine to protect it.",
    pointsTitle: "Common signs we treat",
    points: [
      "Sharp or burning pain from the lower back into the buttock and leg",
      "Tingling, pins-and-needles or numbness in the leg or foot",
      "Pain that worsens on sitting, bending, coughing or sneezing",
      "Stiffness and difficulty standing up straight",
      "Neck disc problems causing pain or tingling into the arm",
    ],
    approachTitle: "How we treat it",
    approach: [
      { title: "Nerve & movement assessment", text: "We find which movements ease or aggravate your symptoms and check nerve function." },
      { title: "Pain-relieving positions", text: "Specific directional exercises and positions that take pressure off the irritated nerve." },
      { title: "Spinal mobilisation", text: "Gentle manual therapy to restore movement in stiff spinal segments." },
      { title: "Electrotherapy", text: "TENS or IFT to reduce pain in the early, painful phase." },
      { title: "Core & back strengthening", text: "Progressive exercises to support the spine and lower the chance of recurrence." },
    ],
    faqs: [
      {
        q: "Can a slip disc heal without surgery?",
        a: "Yes, in most cases. Many disc bulges and herniations settle with time and conservative care such as physiotherapy. Surgery is usually considered only for severe or worsening nerve weakness, or pain that does not improve with good conservative treatment — your doctor will advise on this.",
      },
      {
        q: "Is it safe to exercise with sciatica?",
        a: "Usually yes, with the right exercises. Complete bed rest is no longer recommended for most people. Your physiotherapist will choose movements that calm the nerve and avoid ones that aggravate it.",
      },
      {
        q: "How long does sciatica take to get better?",
        a: "Many people improve over a few weeks to a few months. Recovery time varies with the cause, severity and how regularly the home exercises are done.",
      },
    ],
    related: ["back-neck-pain-treatment", "manual-therapy", "electrotherapy"],
  },
  {
    slug: "sports-injury-physiotherapy",
    kind: "condition",
    icon: "run",
    name: "Sports Injuries",
    summary: "Sprains, strains, muscle injuries",
    h1: "Sports Injury Physiotherapy in Jaipur",
    metaTitle: "Sports Injury Physiotherapy & Rehab in Mansarovar, Jaipur",
    metaDescription:
      "Recover from sprains, muscle strains, ligament and overuse injuries. Sports physiotherapy and safe return-to-play rehab in Mansarovar, Jaipur.",
    question: "How does sports injury physiotherapy help you recover?",
    answer:
      "Sports injury physiotherapy helps you recover from sprains, strains, muscle tears and overuse injuries, and return to sport safely. Treatment combines pain and swelling control, hands-on therapy, progressive strengthening and sport-specific training — so the injured area heals properly and is less likely to be injured again.",
    pointsTitle: "Injuries we commonly treat",
    points: [
      "Ankle and knee sprains",
      "Hamstring, calf and groin strains",
      "Tennis elbow and golfer's elbow",
      "Runner's knee and shin pain",
      "Shoulder pain from gym or overhead sports",
      "Ligament injuries and rehab after ACL surgery",
    ],
    approachTitle: "How we treat it",
    approach: [
      { title: "Injury assessment", text: "We identify the injured structure and what caused it — load, technique or weakness." },
      { title: "Early pain & swelling control", text: "Protection, gentle movement and pain-relief methods in the first phase." },
      { title: "Manual therapy & dry needling", text: "To ease muscle tightness and restore normal movement." },
      { title: "Progressive strength & balance", text: "Step-by-step loading so the tissue becomes stronger than before." },
      { title: "Return-to-play testing", text: "Simple strength and movement tests decide when you're ready — not just the calendar." },
    ],
    faqs: [
      {
        q: "Should I use ice or heat for a sports injury?",
        a: "For a fresh injury in the first day or two, gentle cold and rest from aggravating activity can help with pain. After that, gradual movement is usually better. Your physiotherapist will guide you based on the injury.",
      },
      {
        q: "When can I return to my sport?",
        a: "When you have full, pain-free movement, enough strength and confidence in the injured area. We use simple strength and movement tests to decide, rather than a fixed number of days.",
      },
      {
        q: "Do I need to stop training completely?",
        a: "Not always. In many cases you can keep training the rest of your body while the injured area recovers. Your plan will include what's safe to continue.",
      },
    ],
    related: ["knee-pain-treatment", "dry-needling", "manual-therapy"],
  },
  {
    slug: "knee-pain-treatment",
    kind: "condition",
    icon: "knee",
    name: "Knee & Joint Pain",
    summary: "Knee pain, arthritis, mobility issues",
    h1: "Knee & Joint Pain Treatment in Mansarovar, Jaipur",
    metaTitle: "Knee Pain & Arthritis Physiotherapy in Mansarovar, Jaipur",
    metaDescription:
      "Physiotherapy for knee pain, osteoarthritis and joint stiffness in Mansarovar, Jaipur. Strengthening, manual therapy and pain relief by Dr. C.P. Sharma (PT).",
    question: "Can physiotherapy help knee and joint pain?",
    answer:
      "Yes. Physiotherapy for knee and joint pain reduces pain and stiffness, strengthens the muscles that support the joint and improves how you walk, climb stairs and get up from a chair. It is a first-line treatment for knee osteoarthritis (arthritis) and many other joint problems, and may help delay the need for surgery.",
    pointsTitle: "Common signs we treat",
    points: [
      "Pain when climbing stairs, squatting or getting up from a chair",
      "Morning stiffness or swelling in the knee",
      "Clicking or grinding with pain",
      "Knee giving way or feeling weak",
      "Hip or ankle pain that affects walking",
    ],
    approachTitle: "How we treat it",
    approach: [
      { title: "Joint & walking assessment", text: "We check strength, range of motion, alignment and how you walk." },
      { title: "Pain relief", text: "Manual therapy and electrotherapy to settle pain so you can exercise." },
      { title: "Targeted strengthening", text: "Thigh and hip strengthening to take load off the knee joint." },
      { title: "Mobility & balance", text: "Exercises to improve bending, straightening and steadiness." },
      { title: "Activity advice", text: "Practical guidance on walking, stairs, sitting on the floor and weight management." },
    ],
    faqs: [
      {
        q: "Is walking good for knee arthritis?",
        a: "For most people, yes — regular walking at a comfortable pace helps. Strengthening the thigh and hip muscles makes walking easier and less painful. Your physiotherapist can tell you how much to do.",
      },
      {
        q: "Can physiotherapy help knee osteoarthritis?",
        a: "Yes. Exercise-based physiotherapy is recommended as a core treatment for knee osteoarthritis. It can reduce pain and improve function, although it cannot reverse changes already seen on an X-ray.",
      },
      {
        q: "Do I need knee replacement surgery?",
        a: "That decision is made with your orthopaedic doctor. Many people manage well with physiotherapy. If you do have surgery, physiotherapy before and after it improves recovery.",
      },
    ],
    related: ["post-surgery-rehabilitation", "sports-injury-physiotherapy", "electrotherapy"],
  },
  {
    slug: "shoulder-pain-treatment",
    kind: "condition",
    icon: "shoulder",
    name: "Shoulder Pain",
    summary: "Frozen shoulder, rotator cuff problems",
    h1: "Shoulder Pain & Frozen Shoulder Treatment in Jaipur",
    metaTitle: "Frozen Shoulder & Shoulder Pain Physiotherapy, Jaipur",
    metaDescription:
      "Physiotherapy for frozen shoulder, rotator cuff problems and shoulder pain in Mansarovar, Jaipur. Restore movement and strength with a personalised plan.",
    question: "How does physiotherapy help shoulder pain and frozen shoulder?",
    answer:
      "Physiotherapy is a main treatment for shoulder pain, including frozen shoulder (adhesive capsulitis) and rotator cuff problems. It reduces pain, gradually restores the range of movement and rebuilds strength, so you can reach overhead, get dressed, sleep and work with less pain.",
    pointsTitle: "Common signs we treat",
    points: [
      "Pain when lifting the arm or reaching behind your back",
      "Stiffness that makes dressing or combing hair difficult",
      "Night pain or trouble lying on the shoulder",
      "Weakness when lifting objects",
      "Pain after gym, sports or a fall",
    ],
    approachTitle: "How we treat it",
    approach: [
      { title: "Shoulder assessment", text: "We check the shoulder joint, rotator cuff, shoulder blade and neck." },
      { title: "Joint mobilisation", text: "Hands-on techniques to gradually improve stiff shoulder movement." },
      { title: "Rotator cuff strengthening", text: "Progressive exercises for the cuff and shoulder-blade muscles." },
      { title: "Pain relief", text: "Electrotherapy, dry needling or cupping where suitable." },
      { title: "Home programme", text: "Short daily exercises to keep the gains between sessions." },
    ],
    faqs: [
      {
        q: "How long does frozen shoulder take to recover?",
        a: "Frozen shoulder often improves slowly over many months. Physiotherapy helps manage pain and regain movement during this time. Diabetes and thyroid conditions can make it last longer.",
      },
      {
        q: "Should I rest a painful shoulder completely?",
        a: "Usually not. Complete rest can increase stiffness. Gentle, guided movement within comfort is generally better — your physiotherapist will show you what to do.",
      },
      {
        q: "Can shoulder pain come from the neck?",
        a: "Yes. Neck problems can cause pain around the shoulder blade and down the arm. A proper assessment checks both the neck and the shoulder.",
      },
    ],
    related: ["posture-correction", "manual-therapy", "back-neck-pain-treatment"],
  },
  {
    slug: "posture-correction",
    kind: "condition",
    icon: "posture",
    name: "Posture Correction",
    summary: "Forward head, rounded shoulders",
    h1: "Posture Correction Physiotherapy in Jaipur",
    metaTitle: "Posture Correction Physiotherapy in Mansarovar, Jaipur",
    metaDescription:
      "Fix forward head posture, rounded shoulders and desk-job neck pain. Posture correction exercises and ergonomic advice in Mansarovar, Jaipur.",
    question: "What is posture correction physiotherapy?",
    answer:
      "Posture correction physiotherapy helps with forward head posture, rounded shoulders and slouching caused by long hours at desks, laptops and phones. Rather than forcing one 'perfect' posture, it improves mobility, strengthens weak postural muscles and builds better daily habits — easing strain on the neck, shoulders and back.",
    pointsTitle: "Common signs we treat",
    points: [
      "Neck and upper-back ache after desk work",
      "Forward head or 'text neck'",
      "Rounded shoulders",
      "Headaches that start from the neck",
      "Tiredness when sitting or standing for long",
    ],
    approachTitle: "How we treat it",
    approach: [
      { title: "Posture & movement screening", text: "We look at how you sit, stand and move — not just a photo of your posture." },
      { title: "Mobility work", text: "Loosening stiff areas such as the upper back and chest." },
      { title: "Postural strength", text: "Strengthening the deep neck, shoulder-blade and core muscles." },
      { title: "Ergonomic advice", text: "Practical changes to your desk, screen and phone habits." },
      { title: "Short daily routine", text: "A 10-minute plan that fits into a busy work day." },
    ],
    faqs: [
      {
        q: "Can posture really be corrected?",
        a: "Yes. Habits and muscle balance improve with consistent exercise and changes to your workstation. Results come from regular practice over weeks, not from a single session.",
      },
      {
        q: "What is the best sitting posture?",
        a: "The best posture is the next posture — changing position regularly matters more than holding one 'perfect' position. Take short movement breaks every 30–45 minutes.",
      },
      {
        q: "Do posture correctors or belts help?",
        a: "They can remind you to sit up but don't build strength. Exercise and better movement habits give longer-lasting results.",
      },
    ],
    related: ["back-neck-pain-treatment", "shoulder-pain-treatment", "manual-therapy"],
  },
  {
    slug: "post-surgery-rehabilitation",
    kind: "condition",
    icon: "bandage",
    name: "Post-Surgery Rehab",
    summary: "Joint replacement, fracture recovery",
    h1: "Post-Surgery & Fracture Rehabilitation in Jaipur",
    metaTitle: "Post-Surgery Rehab & Knee Replacement Physiotherapy, Jaipur",
    metaDescription:
      "Physiotherapy after knee or hip replacement, ligament surgery and fractures in Mansarovar, Jaipur. Safe, structured rehab that follows your surgeon's plan.",
    question: "What is post-surgery rehabilitation?",
    answer:
      "Post-surgery rehabilitation is structured physiotherapy after operations such as knee or hip replacement, ligament repair or fracture fixation. It helps control pain and swelling, restore joint movement, rebuild strength and get you walking and back to daily activities safely, following your surgeon's protocol.",
    pointsTitle: "Who it helps",
    points: [
      "Knee and hip replacement",
      "ACL and ligament reconstruction",
      "Fracture recovery after plaster or surgery",
      "Spine surgery rehabilitation",
      "Shoulder surgery",
      "Stiffness after a long period of immobilisation",
    ],
    approachTitle: "How we treat it",
    approach: [
      { title: "Follow your surgeon's protocol", text: "Bring your discharge summary — your plan matches your surgeon's instructions." },
      { title: "Pain & swelling control", text: "Positioning, gentle movement and electrotherapy where helpful." },
      { title: "Range of motion", text: "Safe, progressive exercises to restore bending and straightening." },
      { title: "Strengthening", text: "Rebuilding the muscles weakened by surgery and rest." },
      { title: "Walking & balance", text: "From walker to stick to walking independently, step by step." },
    ],
    faqs: [
      {
        q: "When should physiotherapy start after surgery?",
        a: "Often very early — sometimes within a day or two — but timing depends on the operation and your surgeon's instructions. Bring your discharge summary so your plan matches the surgeon's protocol.",
      },
      {
        q: "Is some pain normal during rehab?",
        a: "Mild, short-lived discomfort during exercises can be normal. Sharp pain, increasing swelling, redness, fever or calf pain should be reported to your doctor straight away.",
      },
      {
        q: "How long is rehab after a knee replacement?",
        a: "Most people do structured rehab for several weeks to a few months, with home exercises continuing after that. Progress varies from person to person.",
      },
    ],
    related: ["knee-pain-treatment", "neuro-rehabilitation", "electrotherapy"],
  },
  {
    slug: "neuro-rehabilitation",
    kind: "condition",
    icon: "brain",
    name: "Neuro Rehabilitation",
    summary: "Stroke, balance and walking difficulties",
    h1: "Neuro Rehabilitation (Stroke & Balance) in Jaipur",
    metaTitle: "Neuro Rehabilitation & Stroke Physiotherapy in Jaipur",
    metaDescription:
      "Neuro physiotherapy for stroke recovery, balance problems, Parkinson's and walking difficulties in Mansarovar, Jaipur. Family-friendly home programmes.",
    question: "What is neuro rehabilitation?",
    answer:
      "Neuro rehabilitation is physiotherapy for people with conditions affecting the brain, spinal cord or nerves — such as stroke, Bell's palsy, Parkinson's disease or nerve injuries. It uses repeated, task-based practice to improve movement, balance, walking and independence in daily activities, and teaches family members safe home routines.",
    pointsTitle: "Who it helps",
    points: [
      "Stroke recovery (paralysis or weakness on one side)",
      "Balance problems and fall prevention",
      "Walking difficulties",
      "Parkinson's disease",
      "Bell's palsy and facial weakness",
      "Nerve injuries and neuropathy",
    ],
    approachTitle: "How we treat it",
    approach: [
      { title: "Neuro assessment", text: "Strength, sensation, tone, balance and walking are checked carefully." },
      { title: "Task-based training", text: "Practising real activities — standing up, reaching, walking — many times." },
      { title: "Balance & walking training", text: "Graded exercises to build steadiness and confidence." },
      { title: "Strength & tone", text: "Managing stiffness and building strength in weaker muscles." },
      { title: "Family & home programme", text: "We teach caregivers safe ways to help with exercises and transfers." },
    ],
    faqs: [
      {
        q: "How soon after a stroke should physiotherapy start?",
        a: "As soon as your doctor says it is medically safe. Early, regular rehabilitation generally gives the best chance of recovery, but improvement can continue for many months.",
      },
      {
        q: "Can balance be improved in older adults?",
        a: "Yes. Targeted balance and strength exercises can improve steadiness and reduce the risk of falls at any age.",
      },
      {
        q: "Can family members help with exercises at home?",
        a: "Yes, and it makes a big difference. We teach family members safe ways to help with exercises, walking and transfers.",
      },
    ],
    related: ["post-surgery-rehabilitation", "posture-correction", "electrotherapy"],
  },

  /* ───────────────────────── TREATMENTS ───────────────────────── */
  {
    slug: "manual-therapy",
    kind: "treatment",
    icon: "hands",
    name: "Manual Therapy",
    summary: "Hands-on joint & soft-tissue techniques",
    h1: "Manual Therapy in Jaipur",
    metaTitle: "Manual Therapy by a Certified Manual Therapist | Jaipur",
    metaDescription:
      "Hands-on manual therapy — joint mobilisation, manipulation and soft-tissue release — by Dr. C.P. Sharma (PT), COMT, in Mansarovar, Jaipur.",
    question: "What is manual therapy?",
    answer:
      "Manual therapy is a hands-on physiotherapy treatment in which the therapist uses skilled techniques — joint mobilisation, manipulation and soft-tissue release — to reduce pain, ease stiffness and improve movement. Dr. C.P. Sharma (PT) is a certified orthopaedic manual therapist (COMT) and combines manual therapy with exercise for longer-lasting results.",
    pointsTitle: "Helpful for",
    points: [
      "Back and neck pain",
      "Stiff joints",
      "Shoulder pain and frozen shoulder",
      "Headaches that start from the neck",
      "Muscle tightness and restricted movement",
    ],
    approachTitle: "What to expect",
    approach: [
      { title: "Assessment first", text: "Techniques are chosen only after a clear assessment of your problem." },
      { title: "Gentle and graded", text: "Pressure and technique are adjusted to your comfort at every step." },
      { title: "You stay in control", text: "Tell us about any discomfort — we can change or stop a technique at any time." },
      { title: "Combined with exercise", text: "Manual therapy opens a window of easier movement; exercise keeps the gains." },
    ],
    faqs: [
      {
        q: "Is manual therapy painful?",
        a: "It should not be painful. You may feel pressure or a stretch. Techniques are adjusted to your comfort, and you can ask the therapist to stop at any time.",
      },
      {
        q: "Is manual therapy the same as massage?",
        a: "No. Massage mainly works on muscles, while manual therapy includes specific joint and nerve techniques chosen after an assessment, as part of a treatment plan.",
      },
      {
        q: "Will I hear a 'crack' during treatment?",
        a: "Only with some manipulation techniques, and only if they are suitable and you agree. The sound is gas releasing within the joint — it is not a bone 'going back into place'.",
      },
    ],
    related: ["back-neck-pain-treatment", "dry-needling", "cupping-therapy"],
  },
  {
    slug: "dry-needling",
    kind: "treatment",
    icon: "needle",
    name: "Dry Needling",
    summary: "Trigger-point release for tight muscles",
    h1: "Dry Needling Therapy in Jaipur",
    metaTitle: "Dry Needling by a Certified Therapist (CDNT) | Jaipur",
    metaDescription:
      "Dry needling for muscle knots, trigger points, neck, back and sports pain in Mansarovar, Jaipur — by Dr. C.P. Sharma (PT), certified dry needling therapist.",
    question: "What is dry needling?",
    answer:
      "Dry needling is a treatment in which a trained physiotherapist inserts very thin, sterile, single-use needles into tight muscle knots (trigger points) to release tension and reduce pain. It is called 'dry' because no medicine is injected. Dr. C.P. Sharma (PT) is a certified dry needling therapist (CDNT).",
    pointsTitle: "Helpful for",
    points: [
      "Muscle knots and trigger points",
      "Neck and shoulder tightness",
      "Back pain",
      "Sports muscle strains",
      "Tennis elbow",
      "Heel and calf pain",
    ],
    approachTitle: "What to expect",
    approach: [
      { title: "Suitability check", text: "We review your medical history to make sure dry needling is safe for you." },
      { title: "Sterile, single-use needles", text: "Very fine needles, used once and disposed of safely." },
      { title: "Short treatment", text: "Needles are placed in specific trigger points, usually for a few minutes." },
      { title: "Movement afterwards", text: "Followed by stretches or exercises to make the most of the release." },
    ],
    faqs: [
      {
        q: "Is dry needling the same as acupuncture?",
        a: "No. Both use thin needles, but dry needling is based on modern anatomy and targets specific trigger points in muscles, while acupuncture is based on traditional Chinese medicine.",
      },
      {
        q: "Does dry needling hurt?",
        a: "You may feel a brief prick and a muscle twitch or cramp-like sensation. Mild soreness for a day or two afterwards is common and settles on its own.",
      },
      {
        q: "Who should avoid dry needling?",
        a: "It may not be suitable if you have a strong fear of needles, a bleeding disorder, take blood thinners, are pregnant, or have an infection in the area. Always tell your physiotherapist about your medical history first.",
      },
    ],
    related: ["manual-therapy", "sports-injury-physiotherapy", "cupping-therapy"],
  },
  {
    slug: "cupping-therapy",
    kind: "treatment",
    icon: "cup",
    name: "Cupping Therapy",
    summary: "Gentle suction to ease muscle tightness",
    h1: "Cupping Therapy in Jaipur",
    metaTitle: "Cupping Therapy for Muscle Pain in Mansarovar, Jaipur",
    metaDescription:
      "Physiotherapy-led cupping therapy for muscle tightness and back, neck and shoulder pain in Mansarovar, Jaipur. Used alongside exercise and manual therapy.",
    question: "What is cupping therapy in physiotherapy?",
    answer:
      "Cupping therapy uses cups that create gentle suction on the skin to lift and stretch the soft tissues underneath. In physiotherapy it is used alongside exercise and manual therapy to relieve muscle tightness and make movement more comfortable. It is a supportive treatment rather than a stand-alone cure.",
    pointsTitle: "Helpful for",
    points: [
      "Muscle tightness in the back, neck and shoulders",
      "Muscle soreness after exercise",
      "Myofascial (muscle and fascia) pain",
      "Stiffness, using moving (dynamic) cupping",
    ],
    approachTitle: "What to expect",
    approach: [
      { title: "Assessment first", text: "Cupping is used only when it fits your treatment plan." },
      { title: "Dry cupping", text: "No cuts or bleeding — only gentle suction on the skin." },
      { title: "Static or moving cups", text: "Cups stay in place or glide over the muscle, depending on the goal." },
      { title: "Combined with exercise", text: "Followed by movement to keep the muscles loose." },
    ],
    faqs: [
      {
        q: "Will cupping leave marks?",
        a: "Often, yes — round marks can appear and usually fade within a few days to a week. They are not burns and are generally not painful.",
      },
      {
        q: "Is cupping safe?",
        a: "When done by a trained therapist with clean equipment, cupping is generally safe. It is avoided over broken skin and varicose veins, and in people with certain bleeding or skin conditions.",
      },
      {
        q: "How many cupping sessions will I need?",
        a: "Cupping is one part of your treatment plan, so the number of sessions depends on your overall condition rather than on the cupping itself.",
      },
    ],
    related: ["manual-therapy", "dry-needling", "back-neck-pain-treatment"],
  },
  {
    slug: "electrotherapy",
    kind: "treatment",
    icon: "bolt",
    name: "Electrotherapy",
    summary: "IFT, TENS & therapeutic ultrasound",
    h1: "Electrotherapy (IFT, TENS & Ultrasound) in Jaipur",
    metaTitle: "Electrotherapy — IFT, TENS & Ultrasound | Mansarovar, Jaipur",
    metaDescription:
      "IFT, TENS and therapeutic ultrasound for pain relief in Mansarovar, Jaipur — used alongside exercise and manual therapy at The Spine Physio.",
    question: "What is electrotherapy in physiotherapy?",
    answer:
      "Electrotherapy uses gentle electrical currents or sound waves to help relieve pain and support recovery. Common types are TENS and IFT (interferential therapy) for pain relief, and therapeutic ultrasound for soft tissues. At The Spine Physio it is used alongside exercise and manual therapy — not as a replacement for them.",
    pointsTitle: "Helpful for",
    points: [
      "Acute back and neck pain",
      "Sciatica and nerve pain",
      "Knee arthritis pain",
      "Muscle spasm",
      "Pain and swelling after surgery",
    ],
    approachTitle: "What to expect",
    approach: [
      { title: "TENS", text: "Small pads deliver a tingling current that helps reduce pain signals." },
      { title: "IFT (interferential therapy)", text: "A deeper, comfortable current often used for back and knee pain." },
      { title: "Therapeutic ultrasound", text: "Sound waves applied with a gel-covered probe over soft tissues." },
      { title: "Safety screening", text: "We check for pacemakers, pregnancy and other reasons to avoid it first." },
    ],
    faqs: [
      {
        q: "Does electrotherapy hurt?",
        a: "No. TENS and IFT feel like tingling or buzzing, and the intensity is set to your comfort. Ultrasound is usually not felt at all or feels slightly warm.",
      },
      {
        q: "Who should not have electrotherapy?",
        a: "It is usually avoided if you have a pacemaker or another implanted electronic device, are pregnant (over the abdomen or lower back), have cancer in the treatment area, or have broken skin. Always share your medical history.",
      },
      {
        q: "Is electrotherapy enough on its own?",
        a: "Usually not. It is best for short-term pain relief while exercise and hands-on treatment address the underlying cause.",
      },
    ],
    related: ["back-neck-pain-treatment", "knee-pain-treatment", "manual-therapy"],
  },
];

export const conditions = services.filter((s) => s.kind === "condition");
export const treatments = services.filter((s) => s.kind === "treatment");

export function getService(slug: string | undefined) {
  return services.find((s) => s.slug === slug);
}

/** General FAQs used on the home page */
export const homeFaqs: Faq[] = [
  {
    q: "Do I need a doctor's referral to see a physiotherapist?",
    a: "No, you can book directly. If you have a referral, prescription or reports (MRI, X-ray), please bring them to your first visit.",
  },
  {
    q: "How do I book an appointment at The Spine Physio?",
    a: "Send us a message on WhatsApp, fill in the booking form on this website, or call +91 96808 37883. We'll reply to confirm a time that suits you.",
  },
  {
    q: "What happens at the first physiotherapy visit?",
    a: "Your first visit includes a detailed assessment, a clear explanation of what is causing your problem, initial treatment and a personalised plan with home exercises.",
  },
  {
    q: "What should I wear and bring?",
    a: "Wear loose, comfortable clothes that allow the painful area to be examined, and bring any reports, prescriptions or hospital discharge summaries you have.",
  },
  {
    q: "Which conditions does The Spine Physio treat?",
    a: "Back and neck pain, slip disc and sciatica, sports injuries, knee and joint pain, shoulder pain and frozen shoulder, posture problems, post-surgery rehabilitation and neuro rehabilitation such as stroke recovery.",
  },
  {
    q: "Where is The Spine Physio located?",
    a: "The clinic is at Sharma Medical, Patrakar Colony, Mansarovar, Jaipur — in front of Chetna Medical.",
  },
];
