/**
 * ─────────────────────────────────────────────────────────────
 *  SINGLE SOURCE OF TRUTH for all clinic details.
 *  Change a value here and it updates every page, the schema
 *  markup, the sitemap and llms.txt.
 *
 *  Items marked TODO need confirming before going live.
 * ─────────────────────────────────────────────────────────────
 */

export type OpeningHours = {
  /** Schema.org day names, e.g. ["Monday", "Tuesday"] */
  days: string[];
  /** 24h "HH:MM" */
  opens: string;
  closes: string;
  /** Human-readable label, e.g. "Mon – Sat" */
  label: string;
};

export const site = {
  name: "The Spine Physio",
  tagline: "Ortho & Neuro Rehabilitation",
  slogan: "Move Better. Live Better.",

  // TODO: replace with the real domain once purchased (no trailing slash).
  url: "https://www.thespinephysio.com",

  locale: "en_IN",
  language: "en-IN",

  doctor: {
    name: "Dr. C.P. Sharma",
    displayName: "Dr. C.P. Sharma (PT)",
    jobTitle: "Consultant Physiotherapist",
    shortBio:
      "Consultant physiotherapist and manual therapist specialising in spine, orthopaedic and neurological rehabilitation.",
    qualifications: [
      { short: "BPT", long: "Bachelor of Physiotherapy" },
      { short: "MPT (Neuro)", long: "Master of Physiotherapy (Neurology)" },
      { short: "CDNT", long: "Certified Dry Needling Therapist" },
      { short: "COMT", long: "Certified Orthopaedic Manual Therapist" },
    ],
  },

  phones: [
    { display: "+91 96808 37883", tel: "+919680837883" },
    { display: "+91 86190 25115", tel: "+918619025115" },
  ],

  /** WhatsApp number in international format, digits only. TODO: confirm which number has WhatsApp. */
  whatsapp: "919680837883",

  address: {
    building: "Sharma Medical",
    street: "Patrakar Colony",
    landmark: "In front of Chetna Medical",
    locality: "Mansarovar",
    city: "Jaipur",
    region: "Rajasthan",
    postalCode: "302020", // TODO: confirm PIN code
    country: "IN",
    countryName: "India",
  },

  /** TODO: add exact pin coordinates from Google Maps (right-click → copy coordinates). */
  geo: null as null | { lat: number; lng: number },

  /**
   * TODO: add real clinic timings. While empty, the site shows
   * "Call or WhatsApp to confirm timings" and omits hours from schema.
   * Example: { days: ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"], opens: "09:00", closes: "20:00", label: "Mon – Sat" }
   */
  hours: [] as OpeningHours[],

  social: [
    { label: "Instagram", handle: "dr_chandra_physio", url: "https://www.instagram.com/dr_chandra_physio/" },
    { label: "Instagram", handle: "The_PhysioPedic", url: "https://www.instagram.com/the_physiopedic/" },
  ],

  /** Date shown as "Last updated" on content pages (YYYY-MM-DD). */
  lastUpdated: "2026-11-12",
} as const;

export const fullAddress = [
  site.address.building,
  site.address.street,
  site.address.locality,
  `${site.address.city}, ${site.address.region} ${site.address.postalCode}`,
].join(", ");

export const mapsQuery = `${site.address.building}, ${site.address.street}, ${site.address.locality}, ${site.address.city}`;
export const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(mapsQuery)}`;
export const mapsEmbedUrl = `https://maps.google.com/maps?q=${encodeURIComponent(mapsQuery)}&z=16&output=embed`;

export const primaryPhone = site.phones[0];

export function whatsappLink(message?: string) {
  const base = `https://wa.me/${site.whatsapp}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

export const defaultWhatsAppMessage = `Hello ${site.name}, I would like to know more about physiotherapy treatment.`;

export function absoluteUrl(path = "/") {
  return path === "/" ? site.url : `${site.url}${path}`;
}

export const navLinks = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/services", label: "Services" },
  { href: "/contact", label: "Contact" },
] as const;
