/** Shared Tailwind class recipes — keeps buttons and layout consistent everywhere. */

export const container = "mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8";

const btnBase =
  "inline-flex min-h-12 items-center justify-center gap-2 rounded-full px-6 py-3 text-base font-semibold " +
  "transition duration-300 ease-out active:scale-[0.98] motion-safe:hover:-translate-y-0.5 " +
  "focus-visible:outline-offset-4 disabled:opacity-60";

export const btn = {
  primary: `${btnBase} bg-primary text-white shadow-soft hover:bg-primary-hover hover:shadow-lift`,
  whatsapp: `${btnBase} bg-whatsapp text-white shadow-soft hover:bg-whatsapp-dark hover:shadow-lift`,
  outline: `${btnBase} border-2 border-line-strong bg-surface text-heading hover:border-primary hover:text-link-hover`,
  ghostLight: `${btnBase} border-2 border-white/40 text-white hover:border-white hover:bg-white/10`,
  white: `${btnBase} bg-white text-navy-800 shadow-soft hover:bg-brand-50`,
};

export const eyebrow =
  "inline-flex items-center gap-2 rounded-full bg-soft px-3.5 py-1.5 text-sm font-semibold text-link";

export const sectionY = "py-16 sm:py-20 lg:py-24";
