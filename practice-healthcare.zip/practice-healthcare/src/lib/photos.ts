import { site } from "./site";

/**
 * All doctor photos used on the site (edited by `npm run images` from /assets-src).
 * Each exists as AVIF + WebP at PHOTO_WIDTHS. Alt text is written for screen readers
 * and image search — describe what is shown, not "image of".
 */
export const PHOTO_WIDTHS = [400, 640, 720];

export type Photo = {
  base: string;
  alt: string;
  /** intrinsic size of the largest file (prevents layout shift) */
  width: number;
  height: number;
  /** focal point kept in view when the photo is cropped by CSS (object-position) */
  focus: string;
};

const dr = site.doctor.displayName;

export const photos = {
  hero: {
    base: "/images/doctor-hero",
    alt: `${dr}, consultant physiotherapist, in a white coat at ${site.name}, Mansarovar, Jaipur`,
    width: 720,
    height: 900,
    focus: "50% 30%",
  },
  spine: {
    base: "/images/doctor-spine",
    alt: `${dr} explaining the spine with an anatomical spine model`,
    width: 720,
    height: 1152,
    focus: "45% 22%",
  },
  kneeCoat: {
    base: "/images/doctor-knee-coat",
    alt: `${dr} explaining knee anatomy with a knee joint model`,
    width: 720,
    height: 900,
    focus: "30% 45%",
  },
  consult: {
    base: "/images/doctor-consult",
    alt: `${dr} writing a personalised treatment plan during a consultation`,
    width: 720,
    height: 900,
    focus: "50% 35%",
  },
  kneeScrubs: {
    base: "/images/doctor-knee-scrubs",
    alt: `${dr} showing a patient how the knee joint works using a model`,
    width: 720,
    height: 900,
    focus: "35% 40%",
  },
  desk: {
    base: "/images/doctor-desk",
    alt: `${dr} at the consultation desk at ${site.name}`,
    width: 720,
    height: 900,
    focus: "55% 30%",
  },
  deskWriting: {
    base: "/images/doctor-desk-writing",
    alt: `${dr} preparing a home exercise programme for a patient`,
    width: 720,
    height: 900,
    focus: "55% 35%",
  },
} satisfies Record<string, Photo>;

/** "Inside the clinic" gallery on the About page */
export const gallery: { photo: Photo; caption: string }[] = [
  { photo: photos.consult, caption: "Every visit starts with a detailed assessment" },
  { photo: photos.kneeScrubs, caption: "Understanding your joint, step by step" },
  { photo: photos.deskWriting, caption: "A home programme written just for you" },
  { photo: photos.desk, caption: "A friendly, unhurried consultation" },
];

/** The most relevant photo for each service page */
const servicePhoto: Record<string, Photo> = {
  "back-neck-pain-treatment": photos.spine,
  "slip-disc-sciatica-treatment": photos.spine,
  "posture-correction": photos.spine,
  "manual-therapy": photos.spine,
  "knee-pain-treatment": photos.kneeCoat,
  "post-surgery-rehabilitation": photos.kneeCoat,
  "sports-injury-physiotherapy": photos.kneeScrubs,
};

export function photoForService(slug: string): Photo {
  return servicePhoto[slug] ?? photos.consult;
}
