import { absoluteUrl, fullAddress, mapsUrl, site } from "./site";
import { conditions, getService, homeFaqs, services, treatments, type Faq, type Service } from "./services";

/* ─────────────────────────────────────────────────────────────
   Page metadata registry. Used by:
   - scripts/prerender.mjs → writes real <head> tags into each HTML file
   - Layout (browser)      → keeps the tab title etc. in sync on navigation
   ───────────────────────────────────────────────────────────── */

export type PageMeta = {
  path: string;
  title: string;
  description: string;
  image?: string;
  imageAlt?: string;
  noindex?: boolean;
  jsonLd: Record<string, unknown>[];
  /** Optional <link rel="preload"> for the LCP image */
  preloadImage?: { srcset: string; sizes: string; type: string };
};

const OG_IMAGE = "/images/og-image.jpg";
const OG_ALT = `${site.name} — ${site.doctor.displayName}, physiotherapist in Mansarovar, Jaipur`;

export const heroImage = {
  base: "/images/doctor-hero",
  widths: [400, 640, 720],
  sizes: "(min-width: 1024px) 440px, (min-width: 640px) 380px, 80vw",
};

const ids = {
  clinic: `${site.url}/#clinic`,
  doctor: `${site.url}/#doctor`,
  website: `${site.url}/#website`,
};

/* ── JSON-LD builders ───────────────────────────────────── */

function clinicSchema() {
  const hours = site.hours.map((h) => ({
    "@type": "OpeningHoursSpecification",
    dayOfWeek: h.days,
    opens: h.opens,
    closes: h.closes,
  }));
  return {
    "@type": ["Physiotherapy", "MedicalClinic"],
    "@id": ids.clinic,
    name: site.name,
    alternateName: `${site.name} — ${site.tagline}`,
    slogan: site.slogan,
    description: `${site.name} is a physiotherapy clinic in Mansarovar, Jaipur offering ${site.tagline.toLowerCase()}, led by ${site.doctor.displayName}.`,
    url: site.url,
    logo: absoluteUrl("/icon-512.png"),
    image: absoluteUrl(OG_IMAGE),
    telephone: site.phones.map((p) => p.tel),
    address: {
      "@type": "PostalAddress",
      streetAddress: `${site.address.building}, ${site.address.street} (${site.address.landmark})`,
      addressLocality: `${site.address.locality}, ${site.address.city}`,
      addressRegion: site.address.region,
      postalCode: site.address.postalCode,
      addressCountry: site.address.country,
    },
    ...(site.geo ? { geo: { "@type": "GeoCoordinates", latitude: site.geo.lat, longitude: site.geo.lng } } : {}),
    ...(hours.length ? { openingHoursSpecification: hours } : {}),
    hasMap: mapsUrl,
    areaServed: [
      { "@type": "Place", name: "Mansarovar, Jaipur" },
      { "@type": "City", name: "Jaipur" },
    ],
    medicalSpecialty: "Physiotherapy",
    availableService: services.map((s) => ({
      "@type": s.kind === "condition" ? "MedicalTherapy" : "MedicalProcedure",
      name: s.kind === "condition" ? `Physiotherapy for ${s.name}` : s.name,
      url: absoluteUrl(`/services/${s.slug}`),
    })),
    employee: { "@id": ids.doctor },
    sameAs: site.social.map((s) => s.url),
    contactPoint: {
      "@type": "ContactPoint",
      telephone: site.phones[0].tel,
      contactType: "appointments",
      availableLanguage: ["English", "Hindi"],
    },
  };
}

function doctorSchema() {
  return {
    "@type": "Person",
    "@id": ids.doctor,
    name: site.doctor.name,
    honorificPrefix: "Dr.",
    jobTitle: site.doctor.jobTitle,
    description: site.doctor.shortBio,
    image: [absoluteUrl("/images/doctor-hero-720.webp"), absoluteUrl("/images/doctor-spine-720.webp")],
    url: absoluteUrl("/about"),
    worksFor: { "@id": ids.clinic },
    knowsAbout: ["Physiotherapy", "Manual therapy", "Dry needling", "Spine rehabilitation", "Neuro rehabilitation", "Sports injury rehabilitation"],
    hasCredential: site.doctor.qualifications.map((q) => ({
      "@type": "EducationalOccupationalCredential",
      name: `${q.long} (${q.short})`,
    })),
    sameAs: site.social.map((s) => s.url),
  };
}

function websiteSchema() {
  return {
    "@type": "WebSite",
    "@id": ids.website,
    url: site.url,
    name: site.name,
    inLanguage: site.language,
    publisher: { "@id": ids.clinic },
  };
}

export function faqSchema(faqs: Faq[]) {
  return {
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };
}

export type Crumb = { name: string; path: string };

export function breadcrumbSchema(items: Crumb[]) {
  return {
    "@type": "BreadcrumbList",
    itemListElement: items.map((c, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: c.name,
      item: absoluteUrl(c.path),
    })),
  };
}

function serviceSchema(s: Service) {
  return {
    "@type": "MedicalWebPage",
    "@id": `${absoluteUrl(`/services/${s.slug}`)}#webpage`,
    url: absoluteUrl(`/services/${s.slug}`),
    name: s.h1,
    description: s.metaDescription,
    inLanguage: site.language,
    isPartOf: { "@id": ids.website },
    about:
      s.kind === "condition"
        ? { "@type": "MedicalCondition", name: s.name }
        : { "@type": "MedicalTherapy", name: s.name },
    audience: { "@type": "Patient" },
    reviewedBy: { "@id": ids.doctor },
    lastReviewed: site.lastUpdated,
    dateModified: site.lastUpdated,
    publisher: { "@id": ids.clinic },
  };
}

/** Clinic + doctor + website appear on every page so search & AI engines always see the core facts. */
function base() {
  return [clinicSchema(), doctorSchema(), websiteSchema()];
}

/* ── Page registry ──────────────────────────────────────── */

export const serviceCrumbs = (s: Service): Crumb[] => [
  { name: "Home", path: "/" },
  { name: "Services", path: "/services" },
  { name: s.name, path: `/services/${s.slug}` },
];

const staticPages: Record<string, Omit<PageMeta, "path">> = {
  "/": {
    title: `Physiotherapist in Mansarovar, Jaipur | ${site.name}`,
    description: `${site.name}: spine, ortho & neuro physiotherapy in Mansarovar, Jaipur by ${site.doctor.displayName} — BPT, MPT, CDNT, COMT. Book on WhatsApp or call today.`,
    jsonLd: [...base(), faqSchema(homeFaqs)],
    preloadImage: {
      srcset: heroImage.widths.map((w) => `${heroImage.base}-${w}.avif ${w}w`).join(", "),
      sizes: heroImage.sizes,
      type: "image/avif",
    },
  },
  "/about": {
    title: `About ${site.doctor.displayName} — Physiotherapist | ${site.name}`,
    description: `Meet ${site.doctor.displayName}, consultant physiotherapist & certified manual therapist (BPT, MPT, CDNT, COMT) at ${site.name}, Mansarovar, Jaipur.`,
    jsonLd: [...base(), breadcrumbSchema([{ name: "Home", path: "/" }, { name: "About", path: "/about" }])],
  },
  "/services": {
    title: `Physiotherapy Services & Conditions Treated | ${site.name}`,
    description: `Treatment for back & neck pain, slip disc, sciatica, sports injuries, knee, shoulder, posture, post-surgery and neuro rehab — plus manual therapy, dry needling, cupping & electrotherapy in Jaipur.`,
    jsonLd: [
      ...base(),
      breadcrumbSchema([{ name: "Home", path: "/" }, { name: "Services", path: "/services" }]),
      {
        "@type": "ItemList",
        name: "Physiotherapy services",
        itemListElement: [...conditions, ...treatments].map((s, i) => ({
          "@type": "ListItem",
          position: i + 1,
          name: s.name,
          url: absoluteUrl(`/services/${s.slug}`),
        })),
      },
    ],
  },
  "/contact": {
    title: `Contact & Book Appointment | ${site.name}, Mansarovar Jaipur`,
    description: `Book a physiotherapy appointment at ${site.name}, ${fullAddress}. WhatsApp or call ${site.phones[0].display}.`,
    jsonLd: [...base(), breadcrumbSchema([{ name: "Home", path: "/" }, { name: "Contact", path: "/contact" }])],
  },
  "/privacy-policy": {
    title: `Privacy Policy | ${site.name}`,
    description: `How ${site.name} handles the information you share through this website and WhatsApp.`,
    jsonLd: [...base()],
  },
  "/terms": {
    title: `Terms of Use | ${site.name}`,
    description: `Terms of use for the ${site.name} website.`,
    jsonLd: [...base()],
  },
  "/medical-disclaimer": {
    title: `Medical Disclaimer | ${site.name}`,
    description: `The health information on this website is general in nature and not a substitute for an in-person assessment.`,
    jsonLd: [...base()],
  },
};

const notFoundMeta: Omit<PageMeta, "path"> = {
  title: `Page not found | ${site.name}`,
  description: "Sorry, this page does not exist.",
  noindex: true,
  jsonLd: [],
};

export function getMeta(pathname: string): PageMeta {
  const path = pathname !== "/" ? pathname.replace(/\/+$/, "") : "/";
  const page = staticPages[path];
  if (page) return { path, ...page };

  const match = path.match(/^\/services\/([^/]+)$/);
  const s = match ? getService(match[1]) : undefined;
  if (s) {
    const branded = `${s.metaTitle} | ${site.name}`;
    return {
      path,
      title: branded.length <= 70 ? branded : s.metaTitle,
      description: s.metaDescription,
      jsonLd: [...base(), serviceSchema(s), breadcrumbSchema(serviceCrumbs(s)), faqSchema(s.faqs)],
    };
  }
  return { path, ...notFoundMeta };
}

export const indexablePaths = [
  "/",
  "/about",
  "/services",
  ...services.map((s) => `/services/${s.slug}`),
  "/contact",
  "/privacy-policy",
  "/terms",
  "/medical-disclaimer",
];

/* ── Head HTML (used at build time) ─────────────────────── */

const esc = (v: string) =>
  v.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

export function renderHead(meta: PageMeta) {
  const url = absoluteUrl(meta.path);
  const image = absoluteUrl(meta.image ?? OG_IMAGE);
  const tags = [
    `<title>${esc(meta.title)}</title>`,
    `<meta name="description" content="${esc(meta.description)}" />`,
    meta.noindex
      ? `<meta name="robots" content="noindex, follow" />`
      : `<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1" />`,
    meta.noindex ? "" : `<link rel="canonical" href="${esc(url)}" />`,
    `<meta property="og:type" content="website" />`,
    `<meta property="og:site_name" content="${esc(site.name)}" />`,
    `<meta property="og:locale" content="${site.locale}" />`,
    `<meta property="og:title" content="${esc(meta.title)}" />`,
    `<meta property="og:description" content="${esc(meta.description)}" />`,
    `<meta property="og:url" content="${esc(url)}" />`,
    `<meta property="og:image" content="${esc(image)}" />`,
    `<meta property="og:image:width" content="1200" />`,
    `<meta property="og:image:height" content="630" />`,
    `<meta property="og:image:alt" content="${esc(meta.imageAlt ?? OG_ALT)}" />`,
    `<meta name="twitter:card" content="summary_large_image" />`,
    `<meta name="twitter:title" content="${esc(meta.title)}" />`,
    `<meta name="twitter:description" content="${esc(meta.description)}" />`,
    `<meta name="twitter:image" content="${esc(image)}" />`,
    `<meta name="geo.region" content="IN-RJ" />`,
    `<meta name="geo.placename" content="${esc(`${site.address.locality}, ${site.address.city}`)}" />`,
    meta.preloadImage
      ? `<link rel="preload" as="image" type="${meta.preloadImage.type}" imagesrcset="${esc(meta.preloadImage.srcset)}" imagesizes="${esc(meta.preloadImage.sizes)}" fetchpriority="high" />`
      : "",
    meta.jsonLd.length
      ? `<script type="application/ld+json">${JSON.stringify({ "@context": "https://schema.org", "@graph": meta.jsonLd }).replace(/</g, "\\u003c")}</script>`
      : "",
  ];
  return tags.filter(Boolean).join("\n    ");
}

/* ── Generated text files (used at build time) ──────────── */

export function buildSitemap() {
  const urls = indexablePaths
    .map(
      (p) =>
        `  <url><loc>${absoluteUrl(p)}</loc><lastmod>${site.lastUpdated}</lastmod><priority>${
          p === "/" ? "1.0" : p.startsWith("/services") || p === "/contact" ? "0.8" : p === "/about" ? "0.7" : "0.3"
        }</priority></url>`,
    )
    .join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
}

export function buildRobots() {
  // AI / answer-engine crawlers are explicitly welcome (GEO).
  const aiBots = ["GPTBot", "OAI-SearchBot", "ChatGPT-User", "ClaudeBot", "Claude-SearchBot", "PerplexityBot", "Google-Extended", "Applebot-Extended", "Bingbot"];
  return [
    "User-agent: *",
    "Allow: /",
    "",
    ...aiBots.flatMap((b) => [`User-agent: ${b}`, "Allow: /", ""]),
    `Sitemap: ${absoluteUrl("/sitemap.xml")}`,
    "",
  ].join("\n");
}

export function buildLlmsTxt() {
  const svc = (list: Service[]) =>
    list.map((s) => `- [${s.name}](${absoluteUrl(`/services/${s.slug}`)}): ${s.answer}`).join("\n");
  const hours = site.hours.length
    ? site.hours.map((h) => `${h.label}: ${h.opens}–${h.closes}`).join("; ")
    : "Please call or WhatsApp to confirm timings.";
  return `# ${site.name}

> ${site.name} (${site.tagline}) is a physiotherapy clinic in ${site.address.locality}, ${site.address.city}, ${site.address.region}, India, led by ${site.doctor.displayName}, ${site.doctor.jobTitle.toLowerCase()} (${site.doctor.qualifications.map((q) => q.short).join(", ")}). It treats spine, joint, sports and neurological conditions with manual therapy, dry needling, cupping, electrotherapy and exercise-based rehabilitation.

## Key facts
- Clinic: ${site.name}
- Physiotherapist: ${site.doctor.displayName} — ${site.doctor.qualifications.map((q) => `${q.long} (${q.short})`).join(", ")}
- Address: ${fullAddress} (${site.address.landmark})
- Phone: ${site.phones.map((p) => p.display).join(", ")}
- WhatsApp: https://wa.me/${site.whatsapp}
- Timings: ${hours}
- Instagram: ${site.social.map((s) => `@${s.handle}`).join(", ")}
- Booking: WhatsApp, phone call, or the form at ${absoluteUrl("/contact")}

## Conditions treated
${svc(conditions)}

## Treatments offered
${svc(treatments)}

## Pages
- [Home](${absoluteUrl("/")})
- [About ${site.doctor.displayName}](${absoluteUrl("/about")})
- [All services](${absoluteUrl("/services")})
- [Contact & booking](${absoluteUrl("/contact")})
- [Medical disclaimer](${absoluteUrl("/medical-disclaimer")})
`;
}
