import { Link } from "react-router";
import { Icon } from "./Icon";
import type { Service } from "@/lib/services";

/** Whole card is one link: big tap target, clear focus ring, gentle lift + icon animation on hover. */
export function ServiceCard({ service, compact = false }: { service: Service; compact?: boolean }) {
  return (
    <Link
      to={`/services/${service.slug}`}
      className="card-lift group flex h-full flex-col rounded-2xl border border-line bg-surface p-5 shadow-soft sm:p-6"
    >
      <span className="inline-flex size-14 items-center justify-center rounded-2xl bg-gradient-to-br from-soft to-subtle text-link ring-1 ring-line-strong transition duration-300 group-hover:scale-110 group-hover:from-primary group-hover:to-primary-hover group-hover:text-white">
        <Icon name={service.icon} className="size-7" />
      </span>
      <h3 className="mt-4 text-lg font-bold text-heading">{service.name}</h3>
      <p className="mt-1.5 text-fg-muted">{service.summary}</p>
      {!compact && (
        <span className="mt-auto inline-flex items-center gap-1.5 pt-4 text-sm font-semibold text-link">
          Learn more<span className="sr-only"> about {service.name}</span>
          <Icon name="arrow-right" className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
        </span>
      )}
    </Link>
  );
}
