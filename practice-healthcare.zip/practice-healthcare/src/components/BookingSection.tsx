import { BookingForm } from "./BookingForm";
import { Icon } from "./Icon";
import { Reveal } from "./Reveal";
import { ExternalLink } from "./ExternalLink";
import { primaryPhone, site, whatsappLink, defaultWhatsAppMessage } from "@/lib/site";
import { container, eyebrow, sectionY } from "@/lib/ui";

/** "Book an appointment" section: form + quick contact options. Used on Home and Contact. */
export function BookingSection({ headingLevel = 2 }: { headingLevel?: 1 | 2 }) {
  const H = headingLevel === 1 ? "h1" : "h2";
  return (
    <section id="book" aria-labelledby="book-title" className={`relative overflow-hidden bg-subtle ${sectionY}`}>
      <div aria-hidden="true" className="pointer-events-none absolute -left-32 top-10 size-96 rounded-full bg-soft blur-3xl" />
      <div className={`${container} relative grid gap-10 lg:grid-cols-5 lg:gap-14`}>
        <Reveal className="lg:col-span-2">
          <p className={eyebrow}>
            <Icon name="calendar" className="size-4" />
            Book an appointment
          </p>
          <H id="book-title" className="text-h2 mt-4">
            Start your recovery today
          </H>
          <p className="text-lead mt-4 text-fg-soft">
            Fill in the form and your request opens in WhatsApp, ready to send. We&apos;ll reply to confirm your time.
          </p>

          <ul className="mt-8 space-y-4">
            <li>
              <a
                href={`tel:${primaryPhone.tel}`}
                className="card-lift flex items-center gap-4 rounded-2xl border border-line bg-surface p-4 shadow-soft"
              >
                <span className="inline-flex size-12 shrink-0 items-center justify-center rounded-xl bg-soft text-link">
                  <Icon name="phone" className="size-6" />
                </span>
                <span>
                  <span className="block text-sm text-fg-muted">Prefer to talk? Call us</span>
                  <span className="block text-lg font-bold text-heading">{primaryPhone.display}</span>
                </span>
              </a>
            </li>
            <li>
              <ExternalLink
                href={whatsappLink(defaultWhatsAppMessage)}
                className="card-lift flex items-center gap-4 rounded-2xl border border-line bg-surface p-4 shadow-soft"
              >
                <span className="inline-flex size-12 shrink-0 items-center justify-center rounded-xl bg-accent-soft text-whatsapp">
                  <Icon name="whatsapp" className="size-6" />
                </span>
                <span>
                  <span className="block text-sm text-fg-muted">Quick question?</span>
                  <span className="block text-lg font-bold text-heading">Chat on WhatsApp</span>
                </span>
              </ExternalLink>
            </li>
            <li className="flex items-start gap-4 rounded-2xl p-4">
              <span className="inline-flex size-12 shrink-0 items-center justify-center rounded-xl bg-surface text-link ring-1 ring-line">
                <Icon name="clock" className="size-6" />
              </span>
              <span>
                <span className="block text-sm text-fg-muted">Clinic timings</span>
                <span className="block font-semibold text-heading">
                  {site.hours.length
                    ? site.hours.map((h) => `${h.label}: ${h.opens}–${h.closes}`).join(" · ")
                    : "Call or WhatsApp to confirm today's timings"}
                </span>
              </span>
            </li>
          </ul>
        </Reveal>

        <Reveal delay={120} className="lg:col-span-3">
          <div className="rounded-3xl border border-line bg-surface p-5 shadow-lift sm:p-8">
            <BookingForm />
          </div>
        </Reveal>
      </div>
    </section>
  );
}
