import { useEffect, useState } from "react";
import { Icon } from "./Icon";

type Theme = "light" | "dark";
const STORAGE_KEY = "theme";

function readStored(): Theme | null {
  try {
    const v = localStorage.getItem(STORAGE_KEY);
    return v === "light" || v === "dark" ? v : null;
  } catch {
    return null; // private mode / storage blocked
  }
}

/**
 * Light / dark switch.
 * - First visit follows the device setting (and keeps following it live).
 * - Once the visitor picks a theme, it's remembered.
 * - The actual theme is applied by a tiny script in <head> before the page paints (no flash).
 * The icon is chosen with CSS (`dark:` variant), so it is correct even before React loads.
 */
export function ThemeToggle({ className = "" }: { className?: string }) {
  const [theme, setTheme] = useState<Theme | null>(null);

  const apply = (next: Theme, persist: boolean) => {
    document.documentElement.dataset.theme = next;
    if (persist) {
      try {
        localStorage.setItem(STORAGE_KEY, next);
      } catch {
        /* ignore */
      }
    }
    setTheme(next);
  };

  useEffect(() => {
    setTheme(document.documentElement.dataset.theme === "dark" ? "dark" : "light");
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = (e: MediaQueryListEvent) => {
      if (!readStored()) apply(e.matches ? "dark" : "light", false);
    };
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  const isDark = theme === "dark";

  return (
    <button
      type="button"
      onClick={() => apply(isDark ? "light" : "dark", true)}
      aria-pressed={theme ? isDark : undefined}
      title="Toggle dark mode"
      className={`relative inline-flex size-11 items-center justify-center rounded-full text-heading ring-1 ring-line transition hover:bg-subtle hover:ring-line-strong ${className}`}
    >
      <span className="sr-only">Dark mode</span>
      <Icon
        name="moon"
        className="size-5 transition duration-500 dark:rotate-90 dark:scale-0 dark:opacity-0"
      />
      <Icon
        name="sun"
        className="absolute size-5 -rotate-90 scale-0 opacity-0 transition duration-500 dark:rotate-0 dark:scale-100 dark:opacity-100"
      />
    </button>
  );
}
