import type { AnchorHTMLAttributes, ReactNode } from "react";

/** Link that opens in a new tab and tells screen-reader users it does. */
export function ExternalLink({ children, ...rest }: AnchorHTMLAttributes<HTMLAnchorElement> & { children: ReactNode }) {
  return (
    <a target="_blank" rel="noopener noreferrer" {...rest}>
      {children}
      <span className="sr-only"> (opens in a new tab)</span>
    </a>
  );
}
