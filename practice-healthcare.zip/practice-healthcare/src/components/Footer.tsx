import { Link } from "react-router";
import { Icon } from "./Icon";
import { Logo } from "./Logo";
import { ExternalLink } from "./ExternalLink";
import { conditions, treatments } from "@/lib/services";
import { fullAddress, mapsUrl, navLinks, site, whatsappLink, defaultWhatsAppMessage } from "@/lib/site";
import { container } from "@/lib/ui";

const heading = "mb-4 text-sm font-bold uppercase tracking-[0.14em] text-on-inverse-accent";
const link = "text-white/80 transition hover:text-white hover:underline underline-offset-4";

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-inverse text-white">
      {/* Decorative wave */}
      <svg
        className="absolute inset-x-0 top-0 h-10 w-full text-page"
        viewBox="0 0 1440 40"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <path fill="currentColor" d="M0 0h1440v8c-240 30-480 30-720 12S240-8 0 18z" />
      </svg>

      <div className={`${container} pb-28 pt-20 md:pb-10`}>
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <Logo tone="dark" />
            <p className="mt-2 text-sm font-semibold text-on-inverse-accent">{site.tagline}</p>
            <p className="mt-4 max-w-sm leading-relaxed text-white/80">
              Spine-focused physiotherapy in {site.address.locality}, {site.address.city} by {site.doctor.displayName} —{" "}
              {site.doctor.qualifications.map((q) => q.short).join(", ")}.
            </p>
            <ul className="mt-5 flex flex-wrap gap-3">
              {site.social.map((s) => (
                <li key={s.handle}>
                  <ExternalLink
                    href={s.url}
                    className="inline-flex min-h-11 items-center gap-2 rounded-full bg-white/10 px-4 text-sm font-semibold transition hover:bg-white/20"
                  >
                    <Icon name="instagram" className="size-5" />@{s.handle}
                  </ExternalLink>
                </li>
              ))}
            </ul>
          </div>

          <nav aria-label="Footer pages" className="lg:col-span-2">
            <h2 className={heading}>Clinic</h2>
            <ul className="space-y-3">
              {navLinks.map((l) => (
                <li key={l.href}>
                  <Link to={l.href} className={link}>
                    {l.label}
                  </Link>
                </li>
              ))}
              <li>
                <Link to="/contact#book" className={link}>
                  Book appointment
                </Link>
              </li>
            </ul>
          </nav>

          <nav aria-label="Footer services" className="lg:col-span-3">
            <h2 className={heading}>Conditions &amp; treatments</h2>
            <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-1">
              {[...conditions.slice(0, 6), ...treatments.slice(0, 2)].map((s) => (
                <li key={s.slug}>
                  <Link to={`/services/${s.slug}`} className={link}>
                    {s.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div className="lg:col-span-3">
            <h2 className={heading}>Visit us</h2>
            <address className="space-y-4 not-italic">
              <ExternalLink href={mapsUrl} className={`flex gap-3 ${link}`}>
                <Icon name="map-pin" className="mt-0.5 size-5 shrink-0 text-on-inverse-accent" />
                <span>
                  {fullAddress}
                  <span className="block text-sm text-white/70">{site.address.landmark}</span>
                </span>
              </ExternalLink>
              {site.phones.map((p) => (
                <a key={p.tel} href={`tel:${p.tel}`} className={`flex items-center gap-3 ${link}`}>
                  <Icon name="phone" className="size-5 shrink-0 text-on-inverse-accent" />
                  {p.display}
                </a>
              ))}
              <ExternalLink href={whatsappLink(defaultWhatsAppMessage)} className={`flex items-center gap-3 ${link}`}>
                <Icon name="whatsapp" className="size-5 shrink-0 text-on-inverse-accent" />
                WhatsApp us
              </ExternalLink>
              <p className="flex gap-3 text-white/80">
                <Icon name="clock" className="mt-0.5 size-5 shrink-0 text-on-inverse-accent" />
                <span>
                  {site.hours.length
                    ? site.hours.map((h) => `${h.label}: ${h.opens}–${h.closes}`).join(" · ")
                    : "Call or WhatsApp to confirm today's timings"}
                </span>
              </p>
            </address>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-4 border-t border-white/15 pt-6 text-sm text-white/70 md:flex-row md:items-center md:justify-between">
          <p>
            © <span suppressHydrationWarning>{new Date().getFullYear()}</span> {site.name}. All rights reserved.
          </p>
          <ul className="flex flex-wrap gap-x-6 gap-y-2">
            <li>
              <Link to="/privacy-policy" className={link}>Privacy Policy</Link>
            </li>
            <li>
              <Link to="/terms" className={link}>Terms of Use</Link>
            </li>
            <li>
              <Link to="/medical-disclaimer" className={link}>Medical Disclaimer</Link>
            </li>
          </ul>
        </div>
      </div>
    </footer>
  );
}
