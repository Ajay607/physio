import type { CSSProperties } from "react";

/** Vertebrae of the logo mark: [x, y, width, height, rotation, cx, cy] — a natural S-curved spine. */
const vertebrae: [number, number, number, number, number, number, number][] = [
  [29.75, 17.7, 6.5, 3.6, 24, 33, 19.5],
  [26.75, 22.85, 7.5, 3.9, 17, 30.5, 24.8],
  [25.4, 28.15, 8.2, 4.1, 0, 29.5, 30.2],
  [26, 33.4, 9, 4.4, -17, 30.5, 35.6],
  [28.1, 38.7, 9.8, 4.6, -20, 33, 41],
  [29.3, 44, 10.4, 4.8, -3, 34.5, 46.4],
  [28, 49.3, 11, 5, 10, 33.5, 51.8],
];

type MarkProps = {
  className?: string;
  tone?: "light" | "dark";
  /** Animate vertebrae stacking in + the ring drawing (hero use) */
  animated?: boolean;
};

export function LogoMark({ className = "size-11", tone = "light", animated = false }: MarkProps) {
  const ring = tone === "light" ? "var(--logo-ring)" : "#ffffff";
  const bone = tone === "light" ? "var(--logo-bone)" : "var(--on-inverse-accent)";
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true" focusable="false">
      <path
        d="M50 53.45A28 28 0 1 1 57.38 20.17"
        fill="none"
        stroke={ring}
        strokeWidth="3.5"
        strokeLinecap="round"
        pathLength={1}
        strokeDasharray={animated ? 1 : undefined}
        className={animated ? "motion-safe:animate-draw" : undefined}
      />
      <circle
        cx="36"
        cy="11.5"
        r="4.5"
        fill={bone}
        className={animated ? "vert" : undefined}
        style={animated ? ({ "--i": 7 } as CSSProperties) : undefined}
      />
      {vertebrae.map(([x, y, w, h, r, cx, cy], i) => (
        <rect
          key={i}
          x={x}
          y={y}
          width={w}
          height={h}
          rx={h / 2}
          fill={bone}
          transform={`rotate(${r} ${cx} ${cy})`}
          className={animated ? "vert" : undefined}
          style={animated ? ({ "--i": 6 - i } as CSSProperties) : undefined}
        />
      ))}
    </svg>
  );
}

type LogoProps = {
  tone?: "light" | "dark";
  className?: string;
  /** Extra screen-reader-only text, e.g. " — home" when the logo is a link */
  label?: string;
};

/** Full lockup: mark + "THE Spine Physio" wordmark (real text, so it stays crisp and readable). */
export function Logo({ tone = "light", className = "", label }: LogoProps) {
  const dark = tone === "dark";
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <LogoMark tone={tone} className="size-11 shrink-0 sm:size-12" />
      <span className="flex flex-col leading-none">
        <span className={`text-[0.65rem] font-bold tracking-[0.32em] ${dark ? "text-on-inverse-accent" : "text-link"}`}>
          THE
        </span>{" "}
        <span className={`whitespace-nowrap text-xl font-extrabold tracking-tight sm:text-[1.4rem] ${dark ? "text-white" : "text-heading"}`}>
          Spine <span className={dark ? "text-on-inverse-accent" : "text-link"}>Physio</span>
        </span>
      </span>
      {label && <span className="sr-only">{label}</span>}
    </span>
  );
}
