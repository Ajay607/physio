import { useState } from "react";
import { Icon } from "./Icon";
import { ExternalLink } from "./ExternalLink";
import { fullAddress, mapsEmbedUrl, mapsUrl, site } from "@/lib/site";

/**
 * "Click to load" map. A Google Maps iframe costs ~1 MB and hurts page speed,
 * so we only load it when the visitor asks for it.
 */
export function MapEmbed() {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className="overflow-hidden rounded-3xl border border-line bg-surface shadow-soft">
      <div className="relative aspect-[4/3] w-full sm:aspect-[16/9]">
        {loaded ? (
          <iframe
            src={mapsEmbedUrl}
            title={`Map showing ${site.name}, ${site.address.locality}, ${site.address.city}`}
            className="absolute inset-0 size-full border-0"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            allowFullScreen
          />
        ) : (
          <button
            type="button"
            onClick={() => setLoaded(true)}
            className="group absolute inset-0 flex size-full flex-col items-center justify-center gap-4 bg-subtle p-6 text-center"
          >
            {/* Decorative street-grid pattern */}
            <svg
              aria-hidden="true"
              viewBox="0 0 400 300"
              preserveAspectRatio="xMidYMid slice"
              className="absolute inset-0 size-full text-line-strong"
            >
              <defs>
                <pattern id="map-grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M40 0H0v40" fill="none" stroke="currentColor" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="400" height="300" fill="url(#map-grid)" />
              <path d="M0 210C120 180 240 255 400 165" fill="none" stroke="var(--color-page)" strokeWidth="12" />
              <path d="M150 0C170 100 140 200 175 300" fill="none" stroke="var(--color-page)" strokeWidth="8" />
            </svg>
            <span className="relative inline-flex size-16 items-center justify-center rounded-full bg-primary text-white shadow-lift transition duration-300 group-hover:scale-110 motion-safe:animate-float">
              <Icon name="map-pin" className="size-8" />
            </span>
            <span className="relative rounded-full bg-surface px-5 py-2.5 font-semibold text-heading shadow-soft transition group-hover:bg-primary group-hover:text-white">
              Show map
            </span>
            <span className="relative max-w-xs text-sm text-fg-soft">{fullAddress}</span>
          </button>
        )}
      </div>
      <div className="flex flex-col gap-3 p-5 sm:flex-row sm:items-center sm:justify-between">
        <p className="flex items-start gap-2 text-fg-soft">
          <Icon name="map-pin" className="mt-0.5 size-5 shrink-0 text-link" />
          <span>
            {site.address.building}, {site.address.street}, {site.address.locality}
            <span className="block text-sm text-fg-muted">{site.address.landmark}</span>
          </span>
        </p>
        <ExternalLink
          href={mapsUrl}
          className="inline-flex min-h-11 shrink-0 items-center justify-center gap-2 rounded-full border-2 border-line-strong px-5 font-semibold text-heading transition hover:border-primary hover:text-link-hover"
        >
          Get directions
          <Icon name="arrow-right" className="size-4" />
        </ExternalLink>
      </div>
    </div>
  );
}
