import { Icon } from "./Icon";
import { primaryPhone, whatsappLink, defaultWhatsAppMessage } from "@/lib/site";

/** Mobile: sticky bottom bar (Call | WhatsApp) within easy thumb reach. Desktop: floating WhatsApp button. */
export function FloatingActions() {
  const wa = whatsappLink(defaultWhatsAppMessage);
  return (
    <aside aria-label="Quick contact">
      <div
        className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-page/95 px-3 pt-2 backdrop-blur-md md:hidden"
        style={{ paddingBottom: "max(0.5rem, env(safe-area-inset-bottom))" }}
      >
        <div className="grid grid-cols-2 gap-2">
          <a
            href={`tel:${primaryPhone.tel}`}
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full border-2 border-line-strong font-semibold text-heading active:bg-subtle"
          >
            <Icon name="phone" className="size-5 text-link" />
            Call now
          </a>
          <a
            href={wa}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-whatsapp font-semibold text-white active:bg-whatsapp-dark"
          >
            <Icon name="whatsapp" className="size-5" />
            WhatsApp<span className="sr-only"> (opens in a new tab)</span>
          </a>
        </div>
      </div>

      <a
        href={wa}
        target="_blank"
        rel="noopener noreferrer"
        className="group ping-ring fixed bottom-6 right-6 z-40 hidden size-16 items-center justify-center rounded-full bg-whatsapp text-white shadow-lift transition duration-300 hover:scale-105 hover:bg-whatsapp-dark md:inline-flex"
      >
        <Icon name="whatsapp" className="size-8" />
        <span className="sr-only">Chat with us on WhatsApp (opens in a new tab)</span>
        <span
          aria-hidden="true"
          className="pointer-events-none absolute right-full mr-3 whitespace-nowrap rounded-full bg-inverse px-4 py-2 text-sm font-semibold text-white opacity-0 shadow-soft transition duration-300 group-hover:opacity-100 group-focus-visible:opacity-100"
        >
          Chat on WhatsApp
        </span>
      </a>
    </aside>
  );
}
