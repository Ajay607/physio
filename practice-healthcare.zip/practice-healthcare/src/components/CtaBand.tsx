import { Link } from "react-router";
import { Icon } from "./Icon";
import { LogoMark } from "./Logo";
import { Reveal } from "./Reveal";
import { primaryPhone, whatsappLink, defaultWhatsAppMessage } from "@/lib/site";
import { btn, container } from "@/lib/ui";

type Props = { title?: string; text?: string; concernSlug?: string };

export function CtaBand({
  title = "Don't let pain hold you back",
  text = "Get a proper assessment and a clear, personalised plan. Book your visit in under a minute.",
  concernSlug,
}: Props) {
  const bookHref = concernSlug ? `/contact?concern=${concernSlug}#book` : "/contact#book";
  return (
    <section className={`${container} py-16 sm:py-20`}>
      <Reveal>
        <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-inverse via-inverse-2 to-primary-hover px-6 py-12 text-center text-white shadow-lift sm:px-12 sm:py-16">
          <LogoMark
            tone="dark"
            className="pointer-events-none absolute -right-10 -top-10 size-56 opacity-10 motion-safe:animate-float sm:size-72"
          />
          <h2 className="text-h2 relative mx-auto max-w-2xl text-white">{title}</h2>
          <p className="text-lead relative mx-auto mt-4 max-w-2xl text-white/85">{text}</p>
          <div className="relative mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Link to={bookHref} className={btn.white}>
              <Icon name="calendar" className="size-5" />
              Book appointment
            </Link>
            <a
              href={whatsappLink(defaultWhatsAppMessage)}
              target="_blank"
              rel="noopener noreferrer"
              className={btn.whatsapp}
            >
              <Icon name="whatsapp" className="size-5" />
              WhatsApp us<span className="sr-only"> (opens in a new tab)</span>
            </a>
            <a href={`tel:${primaryPhone.tel}`} className={btn.ghostLight}>
              <Icon name="phone" className="size-5" />
              {primaryPhone.display}
            </a>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
