import type { CSSProperties, ElementType, ReactNode } from "react";

type RevealProps = {
  children: ReactNode;
  /** Delay in ms — use for staggered grids (e.g. index * 80) */
  delay?: number;
  className?: string;
  as?: ElementType;
};

/**
 * Fades + slides content in when it scrolls into view.
 * The observer lives in Layout (one observer for the whole page).
 * Content is always visible if JavaScript fails or the user prefers reduced motion.
 */
export function Reveal({ children, delay = 0, className = "", as: Tag = "div" }: RevealProps) {
  return (
    <Tag className={`reveal ${className}`} style={delay ? ({ "--reveal-delay": `${delay}ms` } as CSSProperties) : undefined}>
      {children}
    </Tag>
  );
}
