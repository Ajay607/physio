import type { Faq as FaqItem } from "@/lib/services";
import { Icon } from "./Icon";

/**
 * Native <details>/<summary> accordion: keyboard and screen-reader accessible
 * with zero JavaScript, and every answer stays in the HTML for search engines.
 */
export function Faq({ items }: { items: FaqItem[] }) {
  return (
    <div className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface shadow-soft">
      {items.map((f, i) => (
        <details key={f.q} className="faq group" open={i === 0}>
          <summary className="flex min-h-14 cursor-pointer items-center justify-between gap-4 px-5 py-4 transition-colors hover:bg-subtle sm:px-6">
            <h3 className="text-base font-bold text-heading sm:text-lg">{f.q}</h3>
            <span className="inline-flex size-8 shrink-0 items-center justify-center rounded-full bg-soft text-link transition-transform duration-300 group-open:rotate-180">
              <Icon name="chevron-down" className="size-5" />
            </span>
          </summary>
          <p className="px-5 pb-5 leading-relaxed text-fg-soft sm:px-6">{f.a}</p>
        </details>
      ))}
    </div>
  );
}
