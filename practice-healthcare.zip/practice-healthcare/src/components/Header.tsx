import { useEffect, useRef, useState } from "react";
import { Link, NavLink, useLocation } from "react-router";
import { Icon } from "./Icon";
import { Logo } from "./Logo";
import { ThemeToggle } from "./ThemeToggle";
import { navLinks, primaryPhone, whatsappLink, defaultWhatsAppMessage } from "@/lib/site";
import { btn, container } from "@/lib/ui";

export function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const toggleRef = useRef<HTMLButtonElement>(null);
  const { pathname } = useLocation();

  // Close the menu whenever the page changes
  useEffect(() => setOpen(false), [pathname]);

  // Subtle shadow once the page is scrolled
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Escape closes the menu and returns focus to the toggle; lock body scroll while open
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        toggleRef.current?.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open]);

  // Close mobile menu if the screen is resized to desktop
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const onChange = () => mq.matches && setOpen(false);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `relative rounded-full px-4 py-2 text-[0.95rem] font-semibold transition-colors ${
      isActive ? "bg-soft text-link" : "text-fg-soft hover:bg-subtle hover:text-link-hover"
    }`;

  return (
    <header
      className={`sticky top-0 z-40 border-b bg-page/90 backdrop-blur-md transition-shadow duration-300 supports-[backdrop-filter]:bg-page/80 ${
        scrolled || open ? "border-line shadow-soft" : "border-transparent"
      }`}
    >
      <div className={`${container} flex h-[4.5rem] items-center justify-between gap-4 lg:h-20`}>
        <Link to="/" className="rounded-lg">
          <Logo label=" — home" />
        </Link>

        {/* Desktop navigation */}
        <nav aria-label="Main" className="hidden lg:block">
          <ul className="flex items-center gap-1">
            {navLinks.map((l) => (
              <li key={l.href}>
                <NavLink to={l.href} end={l.href === "/"} className={linkClass}>
                  {l.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-2 lg:gap-3">
        <ThemeToggle />
        <div className="hidden items-center gap-3 lg:flex">
          <a
            href={`tel:${primaryPhone.tel}`}
            className="inline-flex size-11 items-center justify-center gap-2 whitespace-nowrap rounded-full font-semibold text-heading ring-1 ring-line transition hover:text-link-hover hover:ring-line-strong xl:size-auto xl:px-3 xl:py-2 xl:ring-0"
          >
            <Icon name="phone" className="size-5 text-link" />
            <span className="sr-only xl:not-sr-only">{primaryPhone.display}</span>
          </a>
          <Link to="/contact#book" className={`${btn.primary} min-h-11 whitespace-nowrap px-5`}>
            <Icon name="calendar" className="size-5" />
            Book Appointment
          </Link>
        </div>

        {/* Mobile menu toggle */}
        <button
          ref={toggleRef}
          type="button"
          className="inline-flex size-12 items-center justify-center rounded-full text-heading transition hover:bg-subtle lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          onClick={() => setOpen((o) => !o)}
        >
          <span className="sr-only">{open ? "Close menu" : "Open menu"}</span>
          <span className="relative block size-6" aria-hidden="true">
            <Icon
              name="menu"
              className={`absolute inset-0 size-6 transition duration-300 ${open ? "rotate-90 opacity-0" : "opacity-100"}`}
            />
            <Icon
              name="close"
              className={`absolute inset-0 size-6 transition duration-300 ${open ? "opacity-100" : "-rotate-90 opacity-0"}`}
            />
          </span>
        </button>
        </div>
      </div>

      {/* Mobile menu panel — animated open/close; `inert` hides it from keyboard & screen readers when closed */}
      <div
        id="mobile-menu"
        inert={!open}
        className={`grid transition-[grid-template-rows] duration-300 ease-out lg:hidden ${
          open ? "grid-rows-[1fr]" : "grid-rows-[0fr]"
        }`}
      >
        <div className="overflow-hidden">
          <nav aria-label="Mobile" className={`${container} pb-6 pt-2`}>
            <ul className="flex flex-col gap-1">
              {navLinks.map((l, i) => (
                <li
                  key={l.href}
                  className={`transition duration-300 ${open ? "translate-x-0 opacity-100" : "-translate-x-3 opacity-0"}`}
                  style={{ transitionDelay: open ? `${i * 50 + 80}ms` : "0ms" }}
                >
                  <NavLink
                    to={l.href}
                    end={l.href === "/"}
                    className={({ isActive }) =>
                      `flex min-h-12 items-center justify-between rounded-xl px-4 text-lg font-semibold ${
                        isActive ? "bg-soft text-link" : "text-heading hover:bg-subtle"
                      }`
                    }
                  >
                    {l.label}
                    <Icon name="arrow-right" className="size-5 opacity-60" />
                  </NavLink>
                </li>
              ))}
            </ul>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <Link to="/contact#book" className={btn.primary}>
                <Icon name="calendar" className="size-5" />
                Book Appointment
              </Link>
              <a
                href={whatsappLink(defaultWhatsAppMessage)}
                target="_blank"
                rel="noopener noreferrer"
                className={btn.whatsapp}
              >
                <Icon name="whatsapp" className="size-5" />
                Chat on WhatsApp<span className="sr-only"> (opens in a new tab)</span>
              </a>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
}
