import { PHOTO_WIDTHS, type Photo } from "@/lib/photos";

type PictureProps = {
  /** A photo from src/lib/photos.ts (sets base, alt, width, height) */
  photo?: Photo;
  /** Base path without size/extension, e.g. "/images/doctor-hero" */
  base?: string;
  alt?: string;
  widths?: number[];
  sizes: string;
  /** Intrinsic aspect, used for width/height attributes to prevent layout shift */
  width?: number;
  height?: number;
  priority?: boolean;
  className?: string;
};

/** Modern responsive image: AVIF → WebP fallback, correct sizes, no layout shift. */
export function Picture({
  photo,
  base = photo?.base ?? "",
  alt = photo?.alt ?? "",
  widths = PHOTO_WIDTHS,
  sizes,
  width = photo?.width ?? 720,
  height = photo?.height ?? 900,
  priority = false,
  className = "",
}: PictureProps) {
  const set = (ext: string) => widths.map((w) => `${base}-${w}.${ext} ${w}w`).join(", ");
  const largest = widths[widths.length - 1];
  return (
    <picture>
      <source type="image/avif" srcSet={set("avif")} sizes={sizes} />
      <source type="image/webp" srcSet={set("webp")} sizes={sizes} />
      <img
        src={`${base}-${largest}.webp`}
        alt={alt}
        width={width}
        height={height}
        loading={priority ? "eager" : "lazy"}
        decoding={priority ? "sync" : "async"}
        fetchPriority={priority ? "high" : "auto"}
        className={className}
        style={photo ? { objectPosition: photo.focus } : undefined}
      />
    </picture>
  );
}
