import type { SVGProps } from "react";

/**
 * Lightweight inline icon set (no icon library = less JavaScript).
 * Icons are decorative by default (aria-hidden). If an icon is the
 * only content of a button/link, give that button an aria-label.
 */
const paths = {
  phone: (
    <path d="M5 4h3l2 5-2.5 1.5a11 11 0 0 0 6 6L15 14l5 2v3a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2" />
  ),
  "map-pin": (
    <>
      <path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z" />
      <circle cx="12" cy="9.5" r="2.5" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  instagram: (
    <>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="0.6" fill="currentColor" />
    </>
  ),
  sun: (
    <>
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
    </>
  ),
  moon: <path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z" />,
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  close: <path d="M6 6l12 12M18 6L6 18" />,
  "arrow-right": <path d="M5 12h14M13 6l6 6-6 6" />,
  check: <path d="M5 12.5l4.5 4.5L19 7.5" />,
  "chevron-down": <path d="M6 9l6 6 6-6" />,
  calendar: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M3 10h18M8 3v4M16 3v4" />
    </>
  ),
  shield: (
    <>
      <path d="M12 3l8 3v6c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V6l8-3z" />
      <path d="M8.5 12l2.5 2.5 4.5-5" />
    </>
  ),
  clipboard: (
    <>
      <rect x="5" y="4" width="14" height="17" rx="2" />
      <path d="M9 4V3h6v1M9 10h6M9 14h6M9 18h4" />
    </>
  ),
  "user-heart": (
    <>
      <circle cx="9" cy="8" r="3.5" />
      <path d="M3 20c0-3.3 2.7-6 6-6 1 0 1.9.2 2.7.6" />
      <path d="M17 21s-4-2.4-4-5a2 2 0 0 1 4-.6 2 2 0 0 1 4 .6c0 2.6-4 5-4 5z" />
    </>
  ),
  flask: (
    <>
      <path d="M9 3h6M10 3v6L5 18a2 2 0 0 0 1.7 3h10.6a2 2 0 0 0 1.7-3l-5-9V3" />
      <path d="M7.5 14h9" />
    </>
  ),
  graduation: (
    <>
      <path d="M2 9l10-5 10 5-10 5-10-5z" />
      <path d="M6 11v5c0 1.5 2.7 3 6 3s6-1.5 6-3v-5M22 9v5" />
    </>
  ),
  "trending-up": <path d="M3 17l6-6 4 4 8-8M15 7h6v6" />,
  message: (
    <path d="M21 12a8 8 0 0 1-11.8 7L4 20.5l1.5-4.8A8 8 0 1 1 21 12z" />
  ),
  // ── Conditions & treatments ─────────────────────────────
  spine: <path d="M10 3.5h4M9.5 7.5h5M9 11.5h6M9 15.5h6M9.5 19.5h5" strokeWidth={2.6} />,
  run: (
    <>
      <circle cx="15" cy="4.5" r="1.8" />
      <path d="M13 8l-3 5 4 3-1 5M10 10l-4 1M13 8l3 3h3M10 13l-3 4H4" />
    </>
  ),
  knee: (
    <>
      <path d="M9 3v5.5a3 3 0 0 0 6 0V3" />
      <path d="M9 21v-5a3 3 0 0 1 6 0v5" />
      <path d="M7 12h1.5M15.5 12H17" />
    </>
  ),
  shoulder: (
    <>
      <circle cx="12" cy="6" r="3" />
      <path d="M4 21v-3a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v3" />
      <path d="M18.5 9.5L20 8M20 12h1.5" />
    </>
  ),
  posture: (
    <>
      <circle cx="12" cy="4.5" r="2" />
      <path d="M12 7v8m0 0l-3 6m3-6l3 6M8 10.5h8" />
      <path d="M5 3v18" strokeDasharray="2 2.5" />
    </>
  ),
  disc: (
    <>
      <rect x="6" y="3" width="12" height="5.5" rx="2" />
      <rect x="6" y="15.5" width="12" height="5.5" rx="2" />
      <path d="M6 12c2-2 10-2 12 0-2 2-10 2-12 0zM18 12h2.5" />
    </>
  ),
  bandage: (
    <>
      <rect x="2.5" y="8.5" width="19" height="7" rx="3.5" transform="rotate(-45 12 12)" />
      <path d="M10.5 10.5h.01M13.5 13.5h.01M13.5 10.5h.01M10.5 13.5h.01" strokeWidth={2.4} />
    </>
  ),
  brain: (
    <>
      <path d="M12 5.5A3 3 0 0 0 6.2 6 3 3 0 0 0 4.5 11a3 3 0 0 0 1.2 5A3 3 0 0 0 12 18.5z" />
      <path d="M12 5.5A3 3 0 0 1 17.8 6a3 3 0 0 1 1.7 5 3 3 0 0 1-1.2 5A3 3 0 0 1 12 18.5V5.5" />
    </>
  ),
  hands: (
    <path d="M7 12V6.5a1.5 1.5 0 0 1 3 0V11M10 10.5V4.5a1.5 1.5 0 0 1 3 0V10.5M13 10.5V5.5a1.5 1.5 0 0 1 3 0V12M16 9.5a1.5 1.5 0 0 1 3 0V14a7 7 0 0 1-7 7h-.5a6 6 0 0 1-5-2.7L4 14.5a1.6 1.6 0 0 1 2.6-1.8L7 13" />
  ),
  cup: (
    <>
      <path d="M6 9h12l-1.5 7.5a3 3 0 0 1-3 2.5h-3a3 3 0 0 1-3-2.5L6 9z" />
      <path d="M9.5 9V5.5h5V9M4 21h16" />
    </>
  ),
  needle: <path d="M4 20l11-11M13.5 5.5l5 5M17 4l3 3M3 21l1-1" />,
  bolt: <path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z" />,
} as const;

export type IconName = keyof typeof paths | "whatsapp";

type IconProps = SVGProps<SVGSVGElement> & { name: IconName; title?: string };

export function Icon({ name, title, className = "size-6", ...rest }: IconProps) {
  const a11y = title ? { role: "img", "aria-label": title } : { "aria-hidden": true as const };

  if (name === "whatsapp") {
    return (
      <svg viewBox="0 0 24 24" className={className} focusable="false" {...a11y} {...rest}>
        <path
          d="M12 2.8a9.2 9.2 0 0 0-7.9 13.9L3 21l4.4-1.1A9.2 9.2 0 1 0 12 2.8z"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinejoin="round"
        />
        <path
          fill="currentColor"
          d="M9.1 7.6c-.3 0-.7.1-.9.5-.3.4-.9 1-.9 2.3s1 2.6 1.1 2.8c.1.2 1.9 3 4.7 4.1 2.3.9 2.8.7 3.3.7.5-.1 1.6-.7 1.8-1.3.2-.6.2-1.2.2-1.3-.1-.1-.2-.2-.5-.3l-1.7-.8c-.3-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.6.1-.3-.1-1.1-.4-2.1-1.3-.8-.7-1.3-1.5-1.4-1.8-.2-.3 0-.4.1-.5l.4-.5.3-.4c.1-.2 0-.3 0-.5l-.8-1.9c-.2-.5-.4-.4-.6-.4h-.5z"
        />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      focusable="false"
      {...a11y}
      {...rest}
    >
      {paths[name]}
    </svg>
  );
}
