import type { ReactNode } from "react";
import { Breadcrumbs } from "./Breadcrumbs";
import type { Crumb } from "@/lib/seo";
import { container } from "@/lib/ui";

type Props = { crumbs: Crumb[]; title: ReactNode; lead?: ReactNode; children?: ReactNode };

/** Soft-gradient page banner with breadcrumbs and the page H1, used on inner pages. */
export function PageHeader({ crumbs, title, lead, children }: Props) {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-subtle to-page">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-24 -top-24 size-80 rounded-full bg-soft blur-3xl motion-safe:animate-float"
      />
      <div className={`${container} relative py-12 sm:py-16`}>
        <Breadcrumbs items={crumbs} />
        <h1 className="text-display max-w-4xl motion-safe:animate-fade-up">{title}</h1>
        {lead && (
          <p className="text-lead mt-5 max-w-3xl text-fg-soft motion-safe:animate-fade-up motion-safe:[animation-delay:120ms]">
            {lead}
          </p>
        )}
        {children}
      </div>
    </section>
  );
}
