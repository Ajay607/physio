import { useEffect, useRef } from "react";
import { Outlet, useLocation } from "react-router";
import { Header } from "./Header";
import { Footer } from "./Footer";
import { FloatingActions } from "./FloatingActions";
import { getMeta } from "@/lib/seo";
import { absoluteUrl } from "@/lib/site";

/** Keep <title>, description, canonical and social tags correct after client-side navigation. */
function useDocumentMeta(pathname: string) {
  useEffect(() => {
    const meta = getMeta(pathname);
    document.title = meta.title;
    const set = (selector: string, attr: string, value: string) => {
      document.querySelector(selector)?.setAttribute(attr, value);
    };
    const url = absoluteUrl(meta.path);
    set('meta[name="description"]', "content", meta.description);
    set('link[rel="canonical"]', "href", url);
    set('meta[property="og:title"]', "content", meta.title);
    set('meta[property="og:description"]', "content", meta.description);
    set('meta[property="og:url"]', "content", url);
    set('meta[name="twitter:title"]', "content", meta.title);
    set('meta[name="twitter:description"]', "content", meta.description);
  }, [pathname]);
}

/**
 * On navigation: scroll to the #hash target (e.g. /contact#book) or to the top,
 * and move keyboard/screen-reader focus to the new page content.
 */
function useRouteFocus(pathname: string, hash: string) {
  const first = useRef(true);
  useEffect(() => {
    const isFirst = first.current;
    first.current = false;

    if (hash) {
      // Wait a frame so the new page has rendered
      requestAnimationFrame(() => {
        const el = document.getElementById(decodeURIComponent(hash.slice(1)));
        if (el) {
          el.scrollIntoView({ block: "start" });
          if (!isFirst) {
            el.setAttribute("tabindex", "-1");
            el.focus({ preventScroll: true });
          }
        }
      });
      return;
    }
    if (isFirst) return;
    window.scrollTo({ top: 0, left: 0, behavior: "instant" });
    document.getElementById("main")?.focus({ preventScroll: true });
  }, [pathname, hash]);
}

/**
 * One IntersectionObserver reveals every `.reveal` element as it scrolls into view.
 * Elements already on screen are shown immediately (no flash), and nothing is ever
 * hidden before JavaScript runs — so content is safe for crawlers and slow devices.
 */
function useScrollReveal(pathname: string) {
  useEffect(() => {
    const root = document.documentElement;
    const els = Array.from(document.querySelectorAll<HTMLElement>(".reveal:not(.is-visible)"));
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (reduced || !("IntersectionObserver" in window)) {
      els.forEach((el) => el.classList.add("is-visible"));
      return;
    }
    // Show anything already in the viewport straight away
    const vh = window.innerHeight;
    els.forEach((el) => {
      const r = el.getBoundingClientRect();
      if (r.top < vh && r.bottom > 0) el.classList.add("is-visible");
    });
    root.classList.add("reveal-ready");

    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            io.unobserve(entry.target);
          }
        }
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.1 },
    );
    els.forEach((el) => {
      if (!el.classList.contains("is-visible")) io.observe(el);
    });
    return () => io.disconnect();
  }, [pathname]);
}

export function Layout() {
  const { pathname, hash } = useLocation();
  useDocumentMeta(pathname);
  useRouteFocus(pathname, hash);
  useScrollReveal(pathname);

  return (
    <>
      <a
        href="#main"
        className="sr-only z-50 rounded-full bg-inverse px-5 py-3 font-semibold text-white focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
      >
        Skip to main content
      </a>
      <Header />
      <main id="main" tabIndex={-1} className="focus:outline-none">
        <Outlet />
      </main>
      <Footer />
      <FloatingActions />
    </>
  );
}
