import { useEffect, useId, useRef, useState, type FormEvent } from "react";
import { Icon } from "./Icon";
import { conditions, treatments } from "@/lib/services";
import { site, whatsappLink } from "@/lib/site";

type Values = {
  name: string;
  phone: string;
  concern: string;
  date: string;
  time: string;
  message: string;
};
type Field = keyof Values;
type Errors = Partial<Record<Field, string>>;

// Kept general on purpose — the clinic confirms the exact time on WhatsApp.
const TIME_SLOTS = ["Morning", "Afternoon", "Evening"];
const OTHER = "Not sure / something else";

const empty: Values = { name: "", phone: "", concern: "", date: "", time: "", message: "" };

/** Accepts "98765 43210", "+91 98765-43210", "098765..." → returns 10 digits or null. */
function normalisePhone(raw: string) {
  let d = raw.replace(/\D/g, "");
  if (d.length === 12 && d.startsWith("91")) d = d.slice(2);
  if (d.length === 11 && d.startsWith("0")) d = d.slice(1);
  return /^[6-9]\d{9}$/.test(d) ? d : null;
}

function todayISO() {
  const now = new Date();
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

function validate(v: Values): Errors {
  const e: Errors = {};
  if (v.name.trim().length < 2) e.name = "Please enter your full name.";
  if (!v.phone.trim()) e.phone = "Please enter your mobile number.";
  else if (!normalisePhone(v.phone)) e.phone = "Please enter a valid 10-digit Indian mobile number.";
  if (!v.concern) e.concern = "Please choose what you need help with.";
  if (!v.date) e.date = "Please choose a preferred date.";
  else if (v.date < todayISO()) e.date = "Please choose today or a future date.";
  if (!v.time) e.time = "Please choose a preferred time.";
  if (v.message.length > 500) e.message = "Please keep the message under 500 characters.";
  return e;
}

const labels: Record<Field, string> = {
  name: "Full name",
  phone: "Mobile number",
  concern: "What do you need help with?",
  date: "Preferred date",
  time: "Preferred time",
  message: "Anything else we should know? (optional)",
};

function buildMessage(v: Values) {
  const date = new Date(`${v.date}T00:00:00`).toLocaleDateString("en-IN", {
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric",
  });
  const lines = [
    `Hello ${site.name}, I would like to book an appointment.`,
    "",
    `*Name:* ${v.name.trim()}`,
    `*Mobile:* ${normalisePhone(v.phone)}`,
    `*Concern:* ${v.concern}`,
    `*Preferred date:* ${date}`,
    `*Preferred time:* ${v.time}`,
  ];
  if (v.message.trim()) lines.push(`*Message:* ${v.message.trim()}`);
  return lines.join("\n");
}

type Props = {
  /** Pre-select a concern (service slug), e.g. from a service page link */
  defaultConcern?: string;
};

export function BookingForm({ defaultConcern }: Props) {
  const uid = useId();
  const id = (f: Field) => `${uid}-${f}`;
  const [values, setValues] = useState<Values>(empty);
  const [errors, setErrors] = useState<Errors>({});
  const [submitted, setSubmitted] = useState(false);
  const [sentUrl, setSentUrl] = useState<string | null>(null);
  const [minDate, setMinDate] = useState<string | undefined>(undefined);
  const summaryRef = useRef<HTMLDivElement>(null);

  // Set date limits on the client only (avoids a mismatch with the pre-rendered HTML)
  useEffect(() => setMinDate(todayISO()), []);

  // Pre-select the concern when arriving from a service page (?concern=slug)
  useEffect(() => {
    const slug = defaultConcern ?? new URLSearchParams(window.location.search).get("concern");
    const match = [...conditions, ...treatments].find((s) => s.slug === slug);
    if (match) setValues((v) => (v.concern ? v : { ...v, concern: match.name }));
  }, [defaultConcern]);

  const update = (field: Field, value: string) => {
    const next = { ...values, [field]: value };
    setValues(next);
    setSentUrl(null);
    // After the first submit attempt, re-check as the user fixes things
    if (submitted) setErrors(validate(next));
  };

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitted(true);
    const found = validate(values);
    setErrors(found);
    if (Object.keys(found).length) {
      requestAnimationFrame(() => summaryRef.current?.focus());
      return;
    }
    const url = whatsappLink(buildMessage(values));
    setSentUrl(url);
    // Opened directly from the click, so pop-up blockers allow it.
    const win = window.open(url, "_blank");
    if (win) win.opener = null;
    else window.location.href = url;
  };

  const errorList = (Object.keys(errors) as Field[]).filter((f) => errors[f]);

  const fieldClass = (f: Field, spacing = "mt-2") =>
    `${spacing} block w-full min-h-12 rounded-xl border-2 bg-surface px-4 py-3 text-base text-fg transition ` +
    `placeholder:text-fg-muted/70 focus:border-primary focus:outline-none focus:ring-4 focus:ring-soft ` +
    (errors[f] ? "border-danger" : "border-line hover:border-line-strong");

  const describedBy = (f: Field, hint?: boolean) =>
    [hint ? `${id(f)}-hint` : "", errors[f] ? `${id(f)}-error` : ""].filter(Boolean).join(" ") || undefined;

  const errorText = (f: Field) =>
    errors[f] ? (
      <p id={`${id(f)}-error`} className="mt-2 flex items-start gap-1.5 text-sm font-medium text-danger">
        <span aria-hidden="true">⚠</span>
        {errors[f]}
      </p>
    ) : null;

  return (
    <form noValidate onSubmit={onSubmit} aria-labelledby={`${uid}-title`} className="space-y-5">
      <h3 id={`${uid}-title`} className="sr-only">
        Appointment request form
      </h3>

      {errorList.length > 0 && (
        <div
          ref={summaryRef}
          tabIndex={-1}
          role="alert"
          className="rounded-xl border-2 border-danger bg-danger-soft p-4 text-danger focus:outline-none focus:ring-4 focus:ring-danger/30"
        >
          <p className="font-bold">
            Please fix {errorList.length === 1 ? "1 problem" : `${errorList.length} problems`} before sending:
          </p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
            {errorList.map((f) => (
              <li key={f}>
                <a
                  href={`#${id(f)}`}
                  className="underline underline-offset-2"
                  onClick={(ev) => {
                    ev.preventDefault();
                    document.getElementById(id(f))?.focus();
                  }}
                >
                  {errors[f]}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor={id("name")} className="font-semibold text-heading">
            {labels.name} <span aria-hidden="true" className="text-danger">*</span>
          </label>
          <input
            id={id("name")}
            name="name"
            type="text"
            autoComplete="name"
            required
            aria-required="true"
            aria-invalid={!!errors.name}
            aria-describedby={describedBy("name")}
            value={values.name}
            onChange={(e) => update("name", e.target.value)}
            className={fieldClass("name")}
          />
          {errorText("name")}
        </div>

        <div>
          <label htmlFor={id("phone")} className="font-semibold text-heading">
            {labels.phone} <span aria-hidden="true" className="text-danger">*</span>
          </label>
          <input
            id={id("phone")}
            name="phone"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            placeholder="98765 43210"
            required
            aria-required="true"
            aria-invalid={!!errors.phone}
            aria-describedby={describedBy("phone")}
            value={values.phone}
            onChange={(e) => update("phone", e.target.value)}
            className={fieldClass("phone")}
          />
          {errorText("phone")}
        </div>
      </div>

      <div>
        <label htmlFor={id("concern")} className="font-semibold text-heading">
          {labels.concern} <span aria-hidden="true" className="text-danger">*</span>
        </label>
        <div className="relative mt-2">
        <select
          id={id("concern")}
          name="concern"
          required
          aria-required="true"
          aria-invalid={!!errors.concern}
          aria-describedby={describedBy("concern")}
          value={values.concern}
          onChange={(e) => update("concern", e.target.value)}
          className={`${fieldClass("concern", "")} appearance-none pr-12`}
        >
          <option value="" disabled>
            Choose one
          </option>
          <optgroup label="Conditions">
            {conditions.map((s) => (
              <option key={s.slug} value={s.name}>
                {s.name}
              </option>
            ))}
          </optgroup>
          <optgroup label="Treatments">
            {treatments.map((s) => (
              <option key={s.slug} value={s.name}>
                {s.name}
              </option>
            ))}
          </optgroup>
          <option value={OTHER}>{OTHER}</option>
        </select>
        <Icon
          name="chevron-down"
          className="pointer-events-none absolute right-4 top-1/2 size-5 -translate-y-1/2 text-link"
        />
        </div>
        {errorText("concern")}
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor={id("date")} className="font-semibold text-heading">
            {labels.date} <span aria-hidden="true" className="text-danger">*</span>
          </label>
          <input
            id={id("date")}
            name="date"
            type="date"
            min={minDate}
            required
            aria-required="true"
            aria-invalid={!!errors.date}
            aria-describedby={describedBy("date")}
            value={values.date}
            onChange={(e) => update("date", e.target.value)}
            className={fieldClass("date")}
          />
          {errorText("date")}
        </div>

        <fieldset aria-describedby={describedBy("time")}>
          <legend className="font-semibold text-heading">
            {labels.time} <span aria-hidden="true" className="text-danger">*</span>
          </legend>
          <div className="mt-2 grid gap-2">
            {TIME_SLOTS.map((slot, i) => (
              <label
                key={slot}
                className={`flex min-h-11 cursor-pointer items-center gap-3 rounded-xl border-2 px-3 py-2 text-sm font-medium transition has-[:checked]:border-primary has-[:checked]:bg-subtle has-[:focus-visible]:ring-4 has-[:focus-visible]:ring-soft ${
                  errors.time ? "border-danger" : "border-line hover:border-line-strong"
                }`}
              >
                <input
                  type="radio"
                  name={`${uid}-time`}
                  id={i === 0 ? id("time") : undefined}
                  value={slot}
                  checked={values.time === slot}
                  onChange={() => update("time", slot)}
                  aria-invalid={!!errors.time}
                  className="size-5 accent-primary"
                />
                {slot}
              </label>
            ))}
          </div>
          {errorText("time")}
        </fieldset>
      </div>

      <div>
        <label htmlFor={id("message")} className="font-semibold text-heading">
          {labels.message}
        </label>
        <textarea
          id={id("message")}
          name="message"
          rows={3}
          maxLength={500}
          aria-invalid={!!errors.message}
          aria-describedby={describedBy("message", true)}
          value={values.message}
          onChange={(e) => update("message", e.target.value)}
          className={`${fieldClass("message")} resize-y`}
          placeholder="e.g. Lower back pain for 2 weeks, worse when sitting"
        />
        <p id={`${id("message")}-hint`} className="mt-1.5 text-sm text-fg-muted">
          {values.message.length}/500 characters
        </p>
        {errorText("message")}
      </div>

      <button
        type="submit"
        className="group inline-flex min-h-14 w-full items-center justify-center gap-2.5 rounded-full bg-whatsapp px-6 py-3 text-lg font-bold text-white shadow-soft transition duration-300 hover:bg-whatsapp-dark hover:shadow-lift active:scale-[0.98] motion-safe:hover:-translate-y-0.5"
      >
        <Icon name="whatsapp" className="size-6 transition-transform duration-300 group-hover:rotate-[-8deg] group-hover:scale-110" />
        Send booking request on WhatsApp
      </button>

      <p className="flex items-start gap-2 text-sm text-fg-muted">
        <Icon name="shield" className="size-5 shrink-0 text-accent" />
        Your details go straight to our WhatsApp — nothing is stored on this website. Please don&apos;t share
        sensitive medical records here.
      </p>

      <div aria-live="polite" className="empty:hidden">
        {sentUrl && (
          <div className="flex items-start gap-3 rounded-xl border-2 border-accent/30 bg-accent-soft p-4 text-fg motion-safe:animate-fade-up">
            <Icon name="check" className="mt-0.5 size-6 shrink-0 text-accent" />
            <p>
              <strong>WhatsApp is opening with your request.</strong> Just tap <em>Send</em> there. Didn&apos;t open?{" "}
              <a href={sentUrl} target="_blank" rel="noopener noreferrer" className="font-semibold text-link underline">
                Open WhatsApp<span className="sr-only"> (opens in a new tab)</span>
              </a>
            </p>
          </div>
        )}
      </div>
    </form>
  );
}
