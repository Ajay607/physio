/**
 * Build-time entry: renders each route to an HTML string.
 * Used only by scripts/prerender.mjs — never shipped to the browser.
 */
import { StrictMode } from "react";
import { renderToString } from "react-dom/server";
import { StaticRouter } from "react-router";
import App from "./App";

export function render(url: string) {
  return renderToString(
    <StrictMode>
      <StaticRouter location={url}>
        <App />
      </StaticRouter>
    </StrictMode>,
  );
}

export { getMeta, renderHead, indexablePaths, buildSitemap, buildRobots, buildLlmsTxt } from "./lib/seo";
