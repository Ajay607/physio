/**
 * Generates every optimised image the site needs from the originals in /assets-src.
 * Run with:  npm run images
 *
 *  1. Doctor photos — edited for the site:
 *       • un-mirrored (phone selfies flip text — e.g. the name on the scrubs)
 *       • cropped to the doctor (removes clutter, old signage, AC unit)
 *       • "portrait mode": busy backgrounds softly blurred, the doctor stays sharp
 *       • one consistent, slightly cool clinical colour grade that matches the site theme
 *       • exported as AVIF + WebP at 3 sizes
 *  2. Favicons / app icons (SVG, ICO, PNG) from public/favicon.svg
 *  3. Social share image (Open Graph, 1200×630) for WhatsApp / Facebook previews
 */
import sharp from "sharp";
import { mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";

const SRC = "assets-src";
const OUT = "public/images";
await mkdir(OUT, { recursive: true });

// Remove previously generated photos so renamed/removed ones don't linger
for (const f of await readdir(OUT)) if (/\.(avif|webp)$/.test(f)) await rm(`${OUT}/${f}`);

const WIDTHS = [400, 640, 720];

/**
 * Photo recipes. All coordinates are in the UN-MIRRORED source image (899×1599).
 *  crop  – area to keep
 *  ratio – output height / width
 *  sharp – shapes (SVG) that stay perfectly sharp; everything else is softly blurred.
 *          Omit to keep the whole photo sharp.
 *  blur  – shapes (SVG) to blur; everything else stays sharp (used when only a small area is busy).
 */
const photos = [
  {
    // White coat, facing camera — hero + social preview
    src: "dr-coat-portrait.jpg",
    name: "doctor-hero",
    crop: { left: 130, top: 300, width: 760, height: 950 },
    ratio: 5 / 4,
  },
  {
    // Clinic scrubs holding a spine model — "Meet your physiotherapist", spine pages
    src: "dr-scrubs-spine-model.jpg",
    name: "doctor-spine",
    crop: { left: 0, top: 100, width: 720, height: 1152 },
    ratio: 8 / 5,
    blur: `<rect x="170" y="80" width="260" height="196"/><rect x="170" y="250" width="100" height="170"/>`,
  },
  {
    // White coat explaining a knee model — About page
    src: "dr-coat-knee-model.jpg",
    name: "doctor-knee-coat",
    crop: { left: 222, top: 420, width: 668, height: 835 },
    ratio: 5 / 4,
  },
  {
    // White coat writing a treatment plan — consultation pages
    src: "dr-coat-writing.jpg",
    name: "doctor-consult",
    crop: { left: 205, top: 330, width: 680, height: 850 },
    ratio: 5 / 4,
  },
  {
    // Scrubs with knee model — joint/sports pages (old banner behind is blurred)
    src: "dr-scrubs-knee-model.jpg",
    name: "doctor-knee-scrubs",
    crop: { left: 150, top: 560, width: 749, height: 936 },
    ratio: 5 / 4,
    sharp: `<ellipse cx="652" cy="890" rx="118" ry="150"/>
            <polygon points="560,985 899,975 899,1600 470,1600 470,1300 555,1120"/>
            <polygon points="560,1060 615,1150 485,1390 380,1360 450,1200"/>
            <polygon points="225,985 325,965 390,1090 480,1160 480,1390 300,1405 210,1260"/>
            <rect x="0" y="1310" width="520" height="290"/>`,
  },
  {
    // Scrubs at desk, smiling — Contact page / gallery
    src: "dr-scrubs-desk-smile.jpg",
    name: "doctor-desk",
    crop: { left: 150, top: 500, width: 749, height: 936 },
    ratio: 5 / 4,
    sharp: `<ellipse cx="578" cy="765" rx="98" ry="128"/>
            <polygon points="500,855 700,855 770,950 800,1080 800,1300 560,1310 330,1160 165,1100 175,1012 320,990 445,930"/>
            <rect x="0" y="1120" width="650" height="480"/>`,
  },
  {
    // Scrubs writing at desk — gallery
    src: "dr-scrubs-desk-writing.jpg",
    name: "doctor-desk-writing",
    crop: { left: 150, top: 450, width: 749, height: 936 },
    ratio: 5 / 4,
    sharp: `<ellipse cx="672" cy="715" rx="100" ry="130"/>
            <polygon points="560,790 805,795 845,950 835,1260 515,1260 470,1040 520,900"/>
            <polygon points="235,965 400,935 530,885 610,1065 255,1120"/>
            <rect x="0" y="1030" width="700" height="570"/>`,
  },
];

/** Feathered greyscale mask: white = shapes, black = rest (or inverted). */
function mask(w, h, shapes, invert) {
  const bg = invert ? "#fff" : "#000";
  const fg = invert ? "#000" : "#fff";
  return Buffer.from(
    `<svg width="${w}" height="${h}" xmlns="http://www.w3.org/2000/svg">
       <defs><filter id="f" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="14"/></filter></defs>
       <rect width="${w}" height="${h}" fill="${bg}"/>
       <g fill="${fg}" filter="url(#f)">${shapes}</g>
     </svg>`,
  );
}

/** Un-mirror, apply portrait-mode blur, crop and colour-grade one photo. Returns a PNG buffer. */
async function edit(p) {
  const meta = await sharp(`${SRC}/${p.src}`).metadata();
  const { width: W, height: H } = meta;
  let img = await sharp(`${SRC}/${p.src}`).rotate().flop().png().toBuffer();

  if (p.sharp || p.blur) {
    const blurred = await sharp(img).blur(16).modulate({ saturation: 0.75 }).png().toBuffer();
    // alpha of the SHARP layer: 255 where the photo must stay crisp
    const keepMask = await sharp(mask(W, H, p.sharp ?? p.blur, !p.sharp)).greyscale().raw().toBuffer();
    // (img has no alpha, so the mask becomes its alpha channel)
    const sharpLayer = await sharp(img)
      .joinChannel(keepMask, { raw: { width: W, height: H, channels: 1 } })
      .png()
      .toBuffer();
    img = await sharp(blurred).composite([{ input: sharpLayer }]).png().toBuffer();
  }

  return sharp(img)
    .extract(p.crop)
    // Clinical grade: gentle contrast, slightly calmer colours, a touch cooler — skin stays natural
    .linear(1.05, -5)
    .modulate({ brightness: 1.03, saturation: 0.94 })
    .recomb([
      [0.985, 0.015, 0],
      [0, 0.995, 0.005],
      [0, 0.02, 1.01],
    ])
    .png()
    .toBuffer();
}

const edited = {};
for (const p of photos) {
  const buf = await edit(p);
  edited[p.name] = buf;
  for (const w of WIDTHS) {
    const h = Math.round(w * p.ratio);
    const resized = sharp(buf).resize(w, h, { fit: "cover", kernel: "lanczos3" }).sharpen({ sigma: 0.6 });
    await resized.clone().avif({ quality: 56, effort: 6 }).toFile(`${OUT}/${p.name}-${w}.avif`);
    await resized.clone().webp({ quality: 80 }).toFile(`${OUT}/${p.name}-${w}.webp`);
  }
  console.log("✓ photo", p.name);
}

/* ── Icons ─────────────────────────────────────────────── */
const favicon = await readFile("public/favicon.svg");
const png = (size, density = 600) => sharp(favicon, { density }).resize(size, size).png().toBuffer();

await writeFile("public/favicon-32.png", await png(32, 400));
await writeFile("public/apple-touch-icon.png", await png(180));
await writeFile("public/icon-192.png", await png(192));
await writeFile("public/icon-512.png", await png(512, 900));
// Maskable icon: extra safe-zone padding so Android can crop it to any shape.
await sharp({ create: { width: 512, height: 512, channels: 4, background: "#0e3a7a" } })
  .composite([{ input: await png(384, 900), left: 64, top: 64 }])
  .png()
  .toFile("public/icon-maskable-512.png");

// favicon.ico (16, 32, 48 px) — for older browsers and Google Search results (needs a multiple of 48px)
{
  const sizes = [16, 32, 48];
  const images = await Promise.all(sizes.map((s) => png(s, 400)));
  const header = Buffer.alloc(6 + 16 * sizes.length);
  header.writeUInt16LE(0, 0); // reserved
  header.writeUInt16LE(1, 2); // type: icon
  header.writeUInt16LE(sizes.length, 4);
  let offset = header.length;
  sizes.forEach((s, i) => {
    const e = 6 + i * 16;
    header.writeUInt8(s, e); // width
    header.writeUInt8(s, e + 1); // height
    header.writeUInt8(0, e + 2); // palette
    header.writeUInt8(0, e + 3); // reserved
    header.writeUInt16LE(1, e + 4); // colour planes
    header.writeUInt16LE(32, e + 6); // bits per pixel
    header.writeUInt32LE(images[i].length, e + 8);
    header.writeUInt32LE(offset, e + 12);
    offset += images[i].length;
  });
  await writeFile("public/favicon.ico", Buffer.concat([header, ...images]));
}
console.log("✓ icons (svg, ico, png, apple, maskable)");

/* ── Open Graph share image ─────────────────────────────── */
const mark = (await readFile("public/brand/logo-mark.svg", "utf8"))
  .replace(/#0e3a7a/g, "#ffffff")
  .replace(/#1a63c6/g, "#9cc8ff");
const markPng = await sharp(Buffer.from(mark), { density: 600 }).resize(120, 120).png().toBuffer();

const photo = await sharp(edited["doctor-hero"])
  .resize(400, 500, { fit: "cover", kernel: "lanczos3" })
  .composite([
    {
      input: Buffer.from('<svg width="400" height="500"><rect width="400" height="500" rx="36" fill="#fff"/></svg>'),
      blend: "dest-in",
    },
  ])
  .png()
  .toBuffer();

const ogSvg = `
<svg width="1200" height="630" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#0b2a5b"/><stop offset="1" stop-color="#1a63c6"/>
    </linearGradient>
  </defs>
  <rect width="1200" height="630" fill="url(#bg)"/>
  <path d="M0 540 C 300 480 600 600 1200 520 L1200 630 L0 630Z" fill="#ffffff" opacity="0.08"/>
  <g font-family="Segoe UI, Arial, sans-serif" fill="#ffffff">
    <text x="210" y="128" font-size="30" font-weight="600" letter-spacing="6" opacity="0.85">THE</text>
    <text x="208" y="190" font-size="68" font-weight="800">Spine Physio</text>
    <text x="70" y="275" font-size="32" font-weight="600" fill="#cfe3ff">Ortho &amp; Neuro Rehabilitation</text>
    <text x="70" y="370" font-size="40" font-weight="700">Dr. C.P. Sharma (PT)</text>
    <text x="70" y="420" font-size="28" fill="#cfe3ff">BPT · MPT (Neuro) · CDNT · COMT</text>
    <text x="70" y="520" font-size="30" font-weight="600">Physiotherapy in Mansarovar, Jaipur</text>
  </g>
</svg>`;

await sharp(Buffer.from(ogSvg))
  .composite([
    { input: markPng, left: 70, top: 70 },
    { input: photo, left: 740, top: 65 },
  ])
  .jpeg({ quality: 82, mozjpeg: true })
  .toFile(`${OUT}/og-image.jpg`);
console.log("✓ og-image");
