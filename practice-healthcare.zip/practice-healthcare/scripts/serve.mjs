/**
 * Tiny static server for testing the production build locally (`npm run preview`).
 * Behaves like Cloudflare Pages / Netlify:
 *   /about  → dist/about/index.html      (clean URLs)
 *   unknown → dist/404.html with status 404
 *   applies the security headers from dist/_headers
 * No dependencies — Node.js only.
 */
import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, join, normalize } from "node:path";
import { brotliCompressSync, gzipSync } from "node:zlib";

const ROOT = join(process.cwd(), "dist");
const PORT = Number(process.env.PORT) || 4173;

const types = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json",
  ".webmanifest": "application/manifest+json",
  ".xml": "application/xml",
  ".txt": "text/plain; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".webp": "image/webp",
  ".avif": "image/avif",
  ".woff2": "font/woff2",
  ".ico": "image/x-icon",
};

// Parse the global "/*" block of _headers so local testing matches production.
let globalHeaders = {};
try {
  const raw = await readFile(join(ROOT, "_headers"), "utf8");
  const block = raw.split(/\n(?=\S)/).find((b) => b.startsWith("/*\n") || b.startsWith("/*\r\n"));
  if (block) {
    for (const line of block.split(/\r?\n/).slice(1)) {
      const m = line.match(/^\s+([\w-]+):\s*(.+)$/);
      if (m && !/upgrade-insecure|Strict-Transport/i.test(m[0])) globalHeaders[m[1]] = m[2].replace(/;\s*upgrade-insecure-requests/, "");
    }
  }
} catch {
  /* no _headers file */
}

async function resolveFile(urlPath) {
  const clean = normalize(decodeURIComponent(urlPath)).replace(/^(\.\.[/\\])+/, "");
  const candidates = [join(ROOT, clean), join(ROOT, clean, "index.html"), join(ROOT, `${clean}.html`)];
  for (const file of candidates) {
    if (!file.startsWith(ROOT)) continue;
    try {
      if ((await stat(file)).isFile()) return file;
    } catch {
      /* try next */
    }
  }
  return null;
}

createServer(async (req, res) => {
  const url = new URL(req.url ?? "/", "http://localhost");
  let file = await resolveFile(url.pathname);
  let status = 200;
  if (!file) {
    file = join(ROOT, "404.html");
    status = 404;
  }
  try {
    let body = await readFile(file);
    const headers = {
      ...globalHeaders,
      "Content-Type": types[extname(file)] ?? "application/octet-stream",
      "Cache-Control": file.includes(`${join("dist", "assets")}`) ? "public, max-age=31536000, immutable" : "no-cache",
      Vary: "Accept-Encoding",
    };
    // Compress text files like real hosting (Cloudflare/Netlify do this automatically)
    if (/\.(html|js|css|json|xml|txt|svg|webmanifest)$/.test(file)) {
      const accept = String(req.headers["accept-encoding"] ?? "");
      if (accept.includes("br")) {
        body = brotliCompressSync(body);
        headers["Content-Encoding"] = "br";
      } else if (accept.includes("gzip")) {
        body = gzipSync(body);
        headers["Content-Encoding"] = "gzip";
      }
    }
    res.writeHead(status, headers);
    res.end(body);
  } catch {
    res.writeHead(500).end("Server error");
  }
  console.log(status, url.pathname);
}).listen(PORT, () => console.log(`Serving dist/ at http://localhost:${PORT}`));
