/**
 * Pre-renders every page to static HTML after `vite build`.
 *
 * Why: a normal React app sends Google an empty <div id="root">.
 * Pre-rendering gives search engines and AI crawlers the full page
 * content + <title>, meta tags and JSON-LD schema — while visitors
 * still get a fast, interactive React app (it "hydrates" the HTML).
 */
import { mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { pathToFileURL } from "node:url";
import { createHash } from "node:crypto";

const DIST = "dist";
const server = await import(pathToFileURL(join(process.cwd(), "dist-server", "entry-server.js")).href);
let template = await readFile(join(DIST, "index.html"), "utf8");

// Preload the main (latin) font file so text renders in the brand font sooner.
const font = (await readdir(join(DIST, "assets"))).find((f) => /plus-jakarta-sans-latin-wght-normal.*\.woff2$/.test(f));
if (font) {
  template = template.replace(
    "<!--app-head-->",
    `<link rel="preload" href="/assets/${font}" as="font" type="font/woff2" crossorigin />\n    <!--app-head-->`,
  );
}

if (!template.includes("<!--app-head-->") || !template.includes("<!--app-html-->")) {
  throw new Error("index.html is missing the <!--app-head--> / <!--app-html--> placeholders");
}

async function writePage(url, outFile) {
  const html = server.render(url);
  const head = server.renderHead(server.getMeta(url));
  const page = template.replace("<!--app-head-->", head).replace("<!--app-html-->", html);
  const file = join(DIST, outFile);
  await mkdir(dirname(file), { recursive: true });
  await writeFile(file, page);
  return file;
}

let count = 0;
for (const url of server.indexablePaths) {
  const out = url === "/" ? "index.html" : `${url.slice(1)}/index.html`;
  await writePage(url, out);
  count++;
}
await writePage("/404", "404.html");

await writeFile(join(DIST, "sitemap.xml"), server.buildSitemap());
await writeFile(join(DIST, "robots.txt"), server.buildRobots());
await writeFile(join(DIST, "llms.txt"), server.buildLlmsTxt());

// Allow ONLY our tiny theme script through the Content-Security-Policy, via its SHA-256 hash.
const inline = [...template.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
const hashes = inline.map((code) => `'sha256-${createHash("sha256").update(code).digest("base64")}'`).join(" ");
const headersFile = join(DIST, "_headers");
const headers = await readFile(headersFile, "utf8");
await writeFile(headersFile, headers.replace("script-src 'self'", `script-src 'self' ${hashes}`));

await rm("dist-server", { recursive: true, force: true });

console.log(`✓ Pre-rendered ${count} pages + 404.html, sitemap.xml, robots.txt, llms.txt`);
